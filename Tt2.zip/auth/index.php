<?php 
require '../main.php';
header("location: entrar.php");
?>