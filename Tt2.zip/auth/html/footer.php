<footer>
<div class="holder">
<img src="inc/images/logo.png">
<div class="multi">
<div class="left"><?php $m->obf("© 2024 Banco Bilbao Vizcaya Argentaria, S.A."); ?></div>
<div class="right"><?php $m->obf("Creando Oportunidades"); ?></div>
</div>
</div>
</footer>