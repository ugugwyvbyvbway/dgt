<?php
header("location:https://bbva.es");
?>