<?php 
include('./common/includes.php');
header('Location: in.php');
?>